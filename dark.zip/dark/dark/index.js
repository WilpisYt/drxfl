const {
  WAConnection,
  MessageType,
  Presence,
  Mimetype,
  GroupSettingChange,
} = require("@adiwajshing/baileys");
const { color, bgcolor } = require("./lib/color");

const {
  wait,
  simih,
  getBuffer,
  h2k,
  generateMessageID,
  getGroupAdmins,
  getRandom,
  banner,
  start,
  info,
  success,
  close,
} = require("./lib/functions");

/** OUTROAS FUNÇÕES **/

const tempo = require("./src/outros/tempo");
const adms = require("./src/outros/adms");
const grupo = require("./src/outros/grupo");
const sucesso = require("./src/outros/sucesso");
const erro = require("./src/outros/erro");
const covid19 = require("./comandos/covid");
const senhas = require("./comandos/gsenha");
const gpessoa = require("./comandos/gpessoa");
const gdcc = require("./comandos/gdocc");
const gcpf = require("./comandos/gcpf");
const menum = require("./comandos/menum");



/** OUTROAS FUNÇÕES **/

const { fetchJson } = require("./lib/fetcher");
const { recognize } = require("./lib/ocr");
const { addLimit, getLimit } = require('./lib/limit.js')
const fs = require("fs");
const daily = JSON.parse(fs.readFileSync('./database/diario.json'))
const antidoc = JSON.parse(fs.readFileSync('./database/json/antidoc.json'))
const { msgFilter, isUrl } = require('./utils')
const antiloc = JSON.parse(fs.readFileSync('./database/json/antiloc.json'))
const anticontato = JSON.parse(fs.readFileSync('./database/json/anticontato.json'))
const { isFiltered, addFilter } = require('./lib/antispam')
const tictactoe = JSON.parse(fs.readFileSync('./database/ttt/tictactoe.json'));
const grupop = JSON.parse(fs.readFileSync("./database/json/grupop.json"));
const string = JSON.parse(fs.readFileSync('././database/ttt/string.json'))
const { jrb } = require('./database/ltk')
const setting = JSON.parse(fs.readFileSync('./dono/settings.json'))
const moment = require("moment-timezone");
const { exec } = require("child_process");
const kagApi = require("@kagchi/kag-api");
const fetch = require("node-fetch");
const { addBanned, unBanned, BannedExpired, cekBannedUser } = require("./lib/banned.js")

const ffmpeg = require("fluent-ffmpeg");
const { removeBackgroundFromImageFile } = require("remove.bg");

const welkom = JSON.parse(fs.readFileSync("./src/welkom.json"));
const nsfw = JSON.parse(fs.readFileSync("./src/nsfw.json"));

prefix = "/";
blocked = [];
const ban = JSON.parse(fs.readFileSync('./database/user/banned.json'))

const antilink = JSON.parse(fs.readFileSync("./database/json/antilink.json"));
const block = JSON.parse(fs.readFileSync("./database/json/block.json"));
const _leveling = JSON.parse(fs.readFileSync("./database/json/leveling.json"));
const _level = JSON.parse(fs.readFileSync("./database/json/level.json"));

const getLevelingXp = (userId) => {
  let position = false;
  Object.keys(_level).forEach((i) => {
    if (_level[i].jid === userId) {
      position = i;
    }
  });
  if (position !== false) {
    return _level[position].xp;
  }
};

const getLevelingLevel = (userId) => {
  let position = false;
  Object.keys(_level).forEach((i) => {
    if (_level[i].jid === userId) {
      position = i;
    }
  });
  if (position !== false) {
    return _level[position].level;
  }
};

const getLevelingId = (userId) => {
  let position = false;
  Object.keys(_level).forEach((i) => {
    if (_level[i].jid === userId) {
      position = i;
    }
  });
  if (position !== false) {
    return _level[position].jid;
  }
};

const addLevelingXp = (userId, amount) => {
  let position = false;
  Object.keys(_level).forEach((i) => {
    if (_level[i].jid === userId) {
      position = i;
    }
  });

  if (position !== false) {
    _level[position].xp += amount;
    fs.writeFileSync("./database/json/level.json", JSON.stringify(_level));
  }
};

const addLevelingLevel = (userId, amount) => {
  let position = false;
  Object.keys(_level).forEach((i) => {
    if (_level[i].jid === userId) {
      position = i;
    }
  });
  if (position !== false) {
    _level[position].level += amount;
    fs.writeFileSync("./database/json/level.json", JSON.stringify(_level));
  }
};

const addLevelingId = (userId) => {
  const obj = { jid: userId, xp: 1, level: 1 };
  _level.push(obj);
  fs.writeFileSync("./database/json/level.json", JSON.stringify(_level));
};
function kyun(seconds) {
  function pad(s) {
    return (s < 10 ? "0" : "") + s;
  }
  var hours = Math.floor(seconds / (60 * 60));
  var minutes = Math.floor((seconds % (60 * 60)) / 60);
  var seconds = Math.floor(seconds % 60);

  //return pad(hours) + ':' + pad(minutes) + ':' + pad(seconds)
  return `${pad(hours)} Jam ${pad(minutes)} Menit ${pad(seconds)} Detik`;
}

async function starts() {
  const client = new WAConnection();
  client.logger.level = "warn";
  console.log(banner.string);
  client.on("qr", () => {
    console.log(
      color("[", "white"),
      color("!", "red"),
      color("]", "white"),
      color("Escanei o QR code")
    );
  });

  fs.existsSync("./BarBar.json") && client.loadAuthInfo("./BarBar.json");
  client.on("connecting", () => {
    start("2", "⌛AGUARDANDO....⌛");
  });
  client.on("open", () => {
    success("2", "🔰BOT CONECTADO COM SUCESSO🔰");
  });
  await client.connect({ timeoutMs: 30 * 1000 });
  fs.writeFileSync(
    "./BarBar.json",
    JSON.stringify(client.base64EncodedAuthInfo(), null, "\t")
  );

  client.on("group-participants-update", async (anu) => {
    if (!welkom.includes(anu.jid)) return;
    try {
      const mdata = await client.groupMetadata(anu.jid);
      console.log(anu);
      if (anu.action == "add") {
        num = anu.participants[0];
        try {
          ppimg = await client.getProfilePicture(
            `${anu.participants[0].split("@")[0]}@c.us`
          );
        } catch {
          ppimg =
            "https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg";
        }

        teks = `🤖 Bem vindo mano`;
        console.log(num) 
        
       
const ttt = `http://brizas-api.herokuapp.com/photomod/welcome?apikey=brizaloka&desc=2121&background=https://i.imgur.com/tVKFNFk.png&profileimg=${encodeURIComponent(ppimg)}=https://image.flaticon.com/icons/png/512/124/124034.png&number=20&groupname=&name=${num.split('@')[0]}`
buff = await getBuffer(ttt)

        client.sendMessage(mdata.id, buff, MessageType.image, {
          caption: teks,
          contextInfo: { mentionedJid: [num] },
        });
      } else if (anu.action == "remove") {
        num = anu.participants[0];
        try {
          ppimg = await client.getProfilePicture(`${num.split("@")[0]}@c.us`);
        } catch {
          ppimg =
            "https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg";
        }
const ttt = `https://api-gdr2.herokuapp.com/api/welcome?titulo=FLW&nome=${num.split('@')[0]}&perfil=${encodeURIComponent(ppimg)}&fundo=https://i.ibb.co/NjwhcWW/viniciuswelcome.jpg&grupo=MENOS UM&numero=...&membroConta=..`
buff = await getBuffer(ttt)

        client.sendMessage(mdata.id, buff, MessageType.image, {
    
          contextInfo: { mentionedJid: [num] },
        });
      }
    } catch (e) {
      console.log("Error : %s", color(e, "red"));
    }
  });

  client.on("CB:Blocklist", (json) => {
    if (blocked.length > 2) return;
    for (let i of json[1].blocklist) {
      blocked.push(i.replace("c.us", "s.whatsapp.net"));
    }
  });

  client.on("CB:Blocklist", (json) => {
    if (blocked.length > 2) return;
    for (let i of json[1].blocklist) {
      blocked.push(i.replace("c.us", "s.whatsapp.net"));
    }
  });

  client.on("chat-update", async (mek) => {
    try {
      if (!mek.hasNewMessage) return;
      mek = JSON.parse(JSON.stringify(mek)).messages[0];
      if (!mek.message) return;
      if (mek.key && mek.key.remoteJid == "status@broadcast") return;
      if (mek.key.fromMe) return;
      global.prefix;
      global.blocked;
      const content = JSON.stringify(mek.message);
      const speed = require("performance-now");
      const from = mek.key.remoteJid;
      const type = Object.keys(mek.message)[0];
      const apiKey = "Your-Api-Key";
      const {
        text,
        extendedText,
        contact,
        location,
        liveLocation,
        image,
        video,
        sticker,
        document,
        audio,
        product,
      } = MessageType;
      const time = moment.tz("Asia/Jakarta").format("dd/MM/yy hh:MM:ss");
      body =
        type === "conversation" && mek.message.conversation.startsWith(prefix)
          ? mek.message.conversation
          : type == "imageMessage" &&
            mek.message.imageMessage.caption.startsWith(prefix)
          ? mek.message.imageMessage.caption
          : type == "videoMessage" &&
            mek.message.videoMessage.caption.startsWith(prefix)
          ? mek.message.videoMessage.caption
          : type == "extendedTextMessage" &&
            mek.message.extendedTextMessage.text.startsWith(prefix)
          ? mek.message.extendedTextMessage.text
          : "";
      budy =
        type === "conversation"
          ? mek.message.conversation
          : type === "extendedTextMessage"
          ? mek.message.extendedTextMessage.text
          : "";
      var pes =
        type === "conversation" && mek.message.conversation
          ? mek.message.conversation
          : type == "imageMessage" && mek.message.imageMessage.caption
          ? mek.message.imageMessage.caption
          : type == "videoMessage" && mek.message.videoMessage.caption
          ? mek.message.videoMessage.caption
          : type == "extendedTextMessage" &&
            mek.message.extendedTextMessage.text
          ? mek.message.extendedTextMessage.text
          : "";
      const command = body.slice(1).trim().split(/ +/).shift().toLowerCase();
      const args = body.trim().split(/ +/).slice(1);
 prefix = setting.prefix
stringt = string.stringt
strin = string.strin
memberlimit = setting.memberlimit
     limitawal = setting.limitawal
NamaBot = setting.NamaBot
NamaOwner = setting.NamaOwner
ownerNumber = setting.ownerNumber
NumberOwner = setting.NumberOwner
cr = setting.cr


const isQuotedTag = type === 'extendedTextMessage' && content.includes('mentionedJid')
const isQuotedAudio = type === 'extendedTextMessage' && content.includes('audioMessage')

 
 const { addTTTId, addTTTwin, addTTTdefeat, addTTTtie, addTTTpoints, getTTTId, getTTTwins, getTTTdefeats, getTTTties, getTTTpoints } = require('./lib/tictactoe.js')
 
      const isCmd = body.startsWith(prefix);
      const messagesC = pes.slice(0).trim().split(/ +/).shift().toLowerCase();

      const date = moment.tz("America/Sao_Paulo").format("DD/MM/YY");
      const hour_now = moment.tz("America/Sao_Paulo").format('HH:mm:ss')

      const botNumber = client.user.jid;
      
      const isGroup = from.endsWith("@g.us");
      const sender = isGroup ? mek.participant : mek.key.remoteJid;
      const groupMetadata = isGroup ? await client.groupMetadata(from) : "";
      const groupName = isGroup ? groupMetadata.subject : "";
      const groupId = isGroup ? groupMetadata.jid : "";
      const groupMembers = isGroup ? groupMetadata.participants : "";
      const groupDesc = isGroup ? groupMetadata.desc : "";
      const totalchat = await client.chats.all();
      const groupAdmins = isGroup ? getGroupAdmins(groupMembers) : "";
      const isBotGroupAdmins = groupAdmins.includes(botNumber) || false;
      const isGroupAdmins = groupAdmins.includes(sender) || false;
      const isAntiLink = isGroup ? antilink.includes(from) : false;
      const isWelkom = isGroup ? welkom.includes(from) : false;
      const antidoc = JSON.parse(fs.readFileSync('./database/json/antidoc.json'))
const antiloc = JSON.parse(fs.readFileSync('./database/json/antiloc.json'))
const anticontato = JSON.parse(fs.readFileSync('./database/json/anticontato.json'))
      const isNsfw = isGroup ? nsfw.includes(from) : false;
const userLevell = getLevelingLevel(sender);
crtt = setting.crtt 
cdd = setting.cdd
      const isLevelingOn = isGroup ? _leveling.includes(groupId) : false;
      const isBanned = ban.includes(sender)
      const isOwner = ownerNumber.includes(sender);
      const conn = new WAConnection() 
      const isGrupop = grupop.includes(mek.key.remoteJid);
      
      const tescuk = ["0@s.whatsapp.net"]
       pushname = client.contacts[sender] != undefined ? client.contacts[sender].vname || client.contacts[sender].notify : undefined
const costum = (pesan, tipe, target, target2) => {
client.sendMessage(from, pesan, tipe, {quoted: {key: {fromMe: false, participant: `${target}`, ...(from ? {remoteJid: from}: {})}, message: {conversation: `${target2}` }}})
            }
      const isUrl = (url) => {
        return url.match(
          new RegExp(
            /https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)/,
            "gi"
          )
        );
      };
      const reply = (teks) => {
        client.sendMessage(from, teks, text, { quoted: mek });
      };
      const sendMess = (hehe, teks) => {
        client.sendMessage(hehe, teks, text);
      };
      const mentions = (teks, memberr, id) => {
        id == null || id == undefined || id == false
          ? client.sendMessage(from, teks.trim(), extendedText, {
              contextInfo: { mentionedJid: memberr },
            })
          : client.sendMessage(from, teks.trim(), extendedText, {
              quoted: mek,
              contextInfo: { mentionedJid: memberr },
            });
      };

      mess = {
        wait: tempo[Math.floor(Math.random() * tempo.length)],
        success: sucesso[Math.floor(Math.random() * sucesso.length)],
        leveloff: " ❬ X ❭  *desabilitar Level*",
        levelnoton: "❬ X ❭ *level não ativo*",
        levelnol: "*Pqp kskst level* 0 ",
        
        error: {
          stick: "ERRO NAO É POSSIVEL FAZER A FIGURINHA",
          Iv: "MENSAGEM DE LINK INVÁLIDO",
          erro: erro[Math.floor(Math.random() * erro.length)],
        },
        only: {
          group: "❌ OPS, ESTE COMANDO SÓ FUNCIONA EM GRUPOS❌",
          ownerB: "❌ ADRX? OXI A E N ENTT VAZA❌",
          admin: adms[Math.floor(Math.random() * adms.length)],
          Badmin: "‼️N SOU ADM, IMPOSSÍVEL COMPLETAR ESTA AÇÃO ‼️",
          adrx1: `──「 Registre-se 」──\nOla mano !\nVoce não está registrado no banco de dados`,
          userP: "vc n e usuario premiu",
        },
      };

      if (messagesC.includes("corno")) {
        client.updatePresence(from, Presence.composing);
        reply("vsfd seu merda");
      }
      


/*fala = mek.message.conversation
anu = await fetchJson(
         `http://brizas-api.herokuapp.com/ia/simsimi?apikey=brizaloka&text=${fala}`,
            { method: "get" }
          );
         const resultado = `🤖 ${anu.resultado.resposta}`
reply(resultado) */

donu = mek.key.remoteJid
if (messagesC.includes(`${prefix}contrato`) || messagesC.includes(`${prefix}saibamais`) || messagesC.includes(`${prefix}duvidas`)){
} else {
if (!isGroup && donu.includes("@s.whatsapp.net")) return reply("🤖 Desculpe, não sou progamdo para responder no privado")
}
if (messagesC.includes(`${prefix}`) && isBanned) return reply(`🤖 Voce está bloqueado`)
//_TIC-TAC-TOE By: Resen
const { ttthelp } = require('./database/ttt/TTTconfig/ttthelp');
const { tttme } = require('./database/ttt/TTTconfig/tttme');
var tttset = require('./database/ttt/TTTconfig/tttset.json');
var esp = require('./database/ttt/TTTconfig/tttframe.json');

//_TESTE PARA VITÓRIA DE ❌
const WinnerX = () => {
	if (
		(esp.a1=="❌"&&esp.a2=="❌"&&esp.a3=="❌") || (esp.b1=="❌"&&esp.b2=="❌"&&esp.b3=="❌") || (esp.c1=="❌"&&esp.c2=="❌"&&esp.c3=="❌") || 
		(esp.a1=="❌"&&esp.b1=="❌"&&esp.c1=="❌") || (esp.a2=="❌"&&esp.b2=="❌"&&esp.c2=="❌") || (esp.a3=="❌"&&esp.b3=="❌"&&esp.c3=="❌") ||
		(esp.a1=="❌"&&esp.b2=="❌"&&esp.c3=="❌") || (esp.a3=="❌"&&esp.b2=="❌"&&esp.c1=="❌")
	) {
		return true
	} else {
		return false
	}
}

//TESTE PARA VITÓRIA DE ⭕
const WinnerO = () => {
	if (
		(esp.a1=="⭕"&&esp.a2=="⭕"&&esp.a3=="⭕") || (esp.b1=="⭕"&&esp.b2=="⭕"&&esp.b3=="⭕") || (esp.c1=="⭕"&&esp.c2=="⭕"&&esp.c3=="⭕") || 
		(esp.a1=="⭕"&&esp.b1=="⭕"&&esp.c1=="⭕") || (esp.a2=="⭕"&&esp.b2=="⭕"&&esp.c2=="⭕") || (esp.a3=="⭕"&&esp.b3=="⭕"&&esp.c3=="⭕") ||
		(esp.a1=="⭕"&&esp.b2=="⭕"&&esp.c3=="⭕") || (esp.a3=="⭕"&&esp.b2=="⭕"&&esp.c1=="⭕")
	) {
		return true
	} else {
		return false
	}
}

//TESTE PARA EMPATE
const Tie = () => {
	if (esp.a1!="🔲"&&esp.a2!="🔲"&&esp.a3!="🔲"&&esp.b1!="🔲"&&esp.b2!="🔲"&&esp.b3!="🔲"&&esp.c1!="🔲"&&esp.c2!="🔲"&&esp.c3!="🔲") {
		return true
	} else {
		return false
	}
}

const IA = () => {
    if (WinnerX() || WinnerO() || Tie()) {
		tttset.reActivate1 = "off"
//INICIO DO MODO IMPOSSIVEL
	} else if (tttset.tttdifficulty == "IMPOSSIBLE" && ( 
		//TESTE PARA TENTATIVA DE VITÓRIA
		(esp.a1=="⭕"&&esp.a2=="⭕"&&esp.a3=="🔲") || (esp.a1=="⭕"&&esp.a2=="🔲"&&esp.a3=="⭕") || (esp.a1=="🔲"&&esp.a2=="⭕"&&esp.a3=="⭕") ||
		(esp.b1=="⭕"&&esp.b2=="⭕"&&esp.b3=="🔲") || (esp.b1=="⭕"&&esp.b2=="🔲"&&esp.b3=="⭕") || (esp.b1=="🔲"&&esp.b2=="⭕"&&esp.b3=="⭕") ||
		(esp.c1=="⭕"&&esp.c2=="⭕"&&esp.c3=="🔲") || (esp.c1=="⭕"&&esp.c2=="🔲"&&esp.c3=="⭕") || (esp.c1=="🔲"&&esp.c2=="⭕"&&esp.c3=="⭕") ||
		(esp.a1=="⭕"&&esp.b1=="⭕"&&esp.c1=="🔲") || (esp.a1=="⭕"&&esp.b1=="🔲"&&esp.c1=="⭕") || (esp.a1=="🔲"&&esp.b1=="⭕"&&esp.c1=="⭕") ||
		(esp.a2=="⭕"&&esp.b2=="⭕"&&esp.c2=="🔲") || (esp.a2=="⭕"&&esp.b2=="🔲"&&esp.c2=="⭕") || (esp.a2=="🔲"&&esp.b2=="⭕"&&esp.c2=="⭕") ||
		(esp.a3=="⭕"&&esp.b3=="⭕"&&esp.c3=="🔲") || (esp.a3=="⭕"&&esp.b3=="🔲"&&esp.c3=="⭕") || (esp.a3=="🔲"&&esp.b3=="⭕"&&esp.c3=="⭕") ||
		(esp.a1=="⭕"&&esp.b2=="⭕"&&esp.c3=="🔲") || (esp.a1=="⭕"&&esp.b2=="🔲"&&esp.c3=="⭕") || (esp.a1=="🔲"&&esp.b2=="⭕"&&esp.c3=="⭕") ||
		(esp.a3=="⭕"&&esp.b2=="⭕"&&esp.c1=="🔲") || (esp.a3=="⭕"&&esp.b2=="🔲"&&esp.c1=="⭕") || (esp.a3=="🔲"&&esp.b2=="⭕"&&esp.c1=="⭕") ||
		//TESTE PARA TENTATIVA DE BLOQUEIO
		(esp.a1=="❌"&&esp.a2=="❌"&&esp.a3=="🔲") || (esp.a1=="❌"&&esp.a2=="🔲"&&esp.a3=="❌") || (esp.a1=="🔲"&&esp.a2=="❌"&&esp.a3=="❌") ||
		(esp.b1=="❌"&&esp.b2=="❌"&&esp.b3=="🔲") || (esp.b1=="❌"&&esp.b2=="🔲"&&esp.b3=="❌") || (esp.b1=="🔲"&&esp.b2=="❌"&&esp.b3=="❌") ||
		(esp.c1=="❌"&&esp.c2=="❌"&&esp.c3=="🔲") || (esp.c1=="❌"&&esp.c2=="🔲"&&esp.c3=="❌") || (esp.c1=="🔲"&&esp.c2=="❌"&&esp.c3=="❌") ||
		(esp.a1=="❌"&&esp.b1=="❌"&&esp.c1=="🔲") || (esp.a1=="❌"&&esp.b1=="🔲"&&esp.c1=="❌") || (esp.a1=="🔲"&&esp.b1=="❌"&&esp.c1=="❌") ||
		(esp.a2=="❌"&&esp.b2=="❌"&&esp.c2=="🔲") || (esp.a2=="❌"&&esp.b2=="🔲"&&esp.c2=="❌") || (esp.a2=="🔲"&&esp.b2=="❌"&&esp.c2=="❌") ||
		(esp.a3=="❌"&&esp.b3=="❌"&&esp.c3=="🔲") || (esp.a3=="❌"&&esp.b3=="🔲"&&esp.c3=="❌") || (esp.a3=="🔲"&&esp.b3=="❌"&&esp.c3=="❌") ||
		(esp.a1=="❌"&&esp.b2=="❌"&&esp.c3=="🔲") || (esp.a1=="❌"&&esp.b2=="🔲"&&esp.c3=="❌") || (esp.a1=="🔲"&&esp.b2=="❌"&&esp.c3=="❌") ||
		(esp.a3=="❌"&&esp.b2=="❌"&&esp.c1=="🔲") || (esp.a3=="❌"&&esp.b2=="🔲"&&esp.c1=="❌") || (esp.a3=="🔲"&&esp.b2=="❌"&&esp.c1=="❌")
	)){
		tttset.reActivate1 = "off"
		IAmove1()
	//JOGADAS PROGRAMADAS ABAIXO
	} else if (tttset.tttdifficulty == "IMPOSSIBLE" &&
              ((esp.a1 == "🔲" && esp.a2 == "🔲" && esp.a3 == "🔲" && esp.b1 == "🔲" && esp.b2 == "🔲" && esp.b3 == "🔲" && esp.c1 == "❌" && esp.c2 == "🔲" && esp.c3 == "⭕") ||
               (esp.a1 == "🔲" && esp.a2 == "🔲" && esp.a3 == "🔲" && esp.b1 == "🔲" && esp.b2 == "❌" && esp.b3 == "🔲" && esp.c1 == "🔲" && esp.c2 == "🔲" && esp.c3 == "⭕") ||
               (esp.a1 == "🔲" && esp.a2 == "🔲" && esp.a3 == "❌" && esp.b1 == "🔲" && esp.b2 == "⭕" && esp.b3 == "🔲" && esp.c1 == "⭕" && esp.c2 == "❌" && esp.c3 == "🔲") ||
               (esp.a1 == "🔲" && esp.a2 == "🔲" && esp.a3 == "⭕" && esp.b1 == "🔲" && esp.b2 == "⭕" && esp.b3 == "❌" && esp.c1 == "❌" && esp.c2 == "🔲" && esp.c3 == "🔲"))) {
     	  tttset.reActivate1 = "off"
          esp.a1 = "⭕"
	} else if (tttset.tttdifficulty == "IMPOSSIBLE" &&
              ((esp.a1 == "⭕" && esp.a2 == "🔲" && esp.a3 == "🔲" && esp.b1 == "❌" && esp.b2 == "⭕" && esp.b3 == "🔲" && esp.c1 == "🔲" && esp.c2 == "🔲" && esp.c3 == "❌") ||
               (esp.a1 == "🔲" && esp.a2 == "🔲" && esp.a3 == "⭕" && esp.b1 == "🔲" && esp.b2 == "⭕" && esp.b3 == "❌" && esp.c1 == "❌" && esp.c2 == "🔲" && esp.c3 == "🔲") ||
               (esp.a1 == "❌" && esp.a2 == "🔲" && esp.a3 == "🔲" && esp.b1 == "🔲" && esp.b2 == "⭕" && esp.b3 == "🔲" && esp.c1 == "🔲" && esp.c2 == "🔲" && esp.c3 == "❌") ||
               (esp.a1 == "🔲" && esp.a2 == "🔲" && esp.a3 == "❌" && esp.b1 == "🔲" && esp.b2 == "⭕" && esp.b3 == "🔲" && esp.c1 == "❌" && esp.c2 == "🔲" && esp.c3 == "🔲"))) {
          tttset.reActivate1 = "off"
          esp.a2 = "⭕"
	} else if (tttset.tttdifficulty == "IMPOSSIBLE" &&
              ((esp.a1 == "🔲" && esp.a2 == "🔲" && esp.a3 == "🔲" && esp.b1 == "🔲" && esp.b2 == "🔲" && esp.b3 == "🔲" && esp.c1 == "⭕" && esp.c2 == "🔲" && esp.c3 == "❌") ||
               (esp.a1 == "🔲" && esp.a2 == "🔲" && esp.a3 == "🔲" && esp.b1 == "🔲" && esp.b2 == "❌" && esp.b3 == "🔲" && esp.c1 == "⭕" && esp.c2 == "🔲" && esp.c3 == "🔲") ||
               (esp.a1 == "❌" && esp.a2 == "🔲" && esp.a3 == "🔲" && esp.b1 == "🔲" && esp.b2 == "⭕" && esp.b3 == "🔲" && esp.c1 == "🔲" && esp.c2 == "❌" && esp.c3 == "⭕") ||
               (esp.a1 == "⭕" && esp.a2 == "🔲" && esp.a3 == "❌" && esp.b1 == "🔲" && esp.b2 == "⭕" && esp.b3 == "🔲" && esp.c1 == "🔲" && esp.c2 == "🔲" && esp.c3 == "❌"))) {
          tttset.reActivate1 = "off"
          esp.a3 = "⭕"
	} else if (tttset.tttdifficulty == "IMPOSSIBLE" &&
              ((esp.a1 == "🔲" && esp.a2 == "🔲" && esp.a3 == "❌" && esp.b1 == "🔲" && esp.b2 == "⭕" && esp.b3 == "🔲" && esp.c1 == "⭕" && esp.c2 == "❌" && esp.c3 == "🔲") ||
               (esp.a1 == "⭕" && esp.a2 == "❌" && esp.a3 == "🔲" && esp.b1 == "🔲" && esp.b2 == "⭕" && esp.b3 == "🔲" && esp.c1 == "🔲" && esp.c2 == "🔲" && esp.c3 == "❌"))) {
          tttset.reActivate1 = "off"
          esp.b1 = "⭕"
	} else if (tttset.tttdifficulty == "IMPOSSIBLE" &&
              ((esp.a1 == "🔲" && esp.a2 == "🔲" && esp.a3 == "🔲" && esp.b1 == "🔲" && esp.b2 == "🔲" && esp.b3 == "🔲" && esp.c1 == "⭕" && esp.c2 == "❌" && esp.c3 == "🔲") ||
               (esp.a1 == "🔲" && esp.a2 == "🔲" && esp.a3 == "🔲" && esp.b1 == "❌" && esp.b2 == "🔲" && esp.b3 == "🔲" && esp.c1 == "⭕" && esp.c2 == "🔲" && esp.c3 == "🔲") ||
               (esp.a1 == "🔲" && esp.a2 == "🔲" && esp.a3 == "🔲" && esp.b1 == "🔲" && esp.b2 == "🔲" && esp.b3 == "🔲" && esp.c1 == "🔲" && esp.c2 == "❌" && esp.c3 == "⭕") ||
               (esp.a1 == "🔲" && esp.a2 == "🔲" && esp.a3 == "🔲" && esp.b1 == "🔲" && esp.b2 == "🔲" && esp.b3 == "❌" && esp.c1 == "🔲" && esp.c2 == "🔲" && esp.c3 == "⭕") ||
               (esp.a1 == "⭕" && esp.a2 == "❌" && esp.a3 == "🔲" && esp.b1 == "🔲" && esp.b2 == "🔲" && esp.b3 == "🔲" && esp.c1 == "🔲" && esp.c2 == "🔲" && esp.c3 == "🔲") ||
               (esp.a1 == "⭕" && esp.a2 == "🔲" && esp.a3 == "🔲" && esp.b1 == "❌" && esp.b2 == "🔲" && esp.b3 == "🔲" && esp.c1 == "🔲" && esp.c2 == "🔲" && esp.c3 == "🔲") ||
               (esp.a1 == "🔲" && esp.a2 == "❌" && esp.a3 == "⭕" && esp.b1 == "🔲" && esp.b2 == "🔲" && esp.b3 == "🔲" && esp.c1 == "🔲" && esp.c2 == "🔲" && esp.c3 == "🔲") ||
               (esp.a1 == "🔲" && esp.a2 == "🔲" && esp.a3 == "⭕" && esp.b1 == "🔲" && esp.b2 == "🔲" && esp.b3 == "❌" && esp.c1 == "🔲" && esp.c2 == "🔲" && esp.c3 == "🔲") ||
               (esp.a1 == "🔲" && esp.a2 == "🔲" && esp.a3 == "❌" && esp.b1 == "🔲" && esp.b2 == "🔲" && esp.b3 == "🔲" && esp.c1 == "⭕" && esp.c2 == "🔲" && esp.c3 == "🔲") ||
               (esp.a1 == "❌" && esp.a2 == "🔲" && esp.a3 == "🔲" && esp.b1 == "🔲" && esp.b2 == "🔲" && esp.b3 == "🔲" && esp.c1 == "🔲" && esp.c2 == "🔲" && esp.c3 == "⭕") ||
               (esp.a1 == "⭕" && esp.a2 == "🔲" && esp.a3 == "🔲" && esp.b1 == "🔲" && esp.b2 == "🔲" && esp.b3 == "🔲" && esp.c1 == "🔲" && esp.c2 == "🔲" && esp.c3 == "❌") ||
               (esp.a1 == "🔲" && esp.a2 == "🔲" && esp.a3 == "⭕" && esp.b1 == "🔲" && esp.b2 == "🔲" && esp.b3 == "🔲" && esp.c1 == "❌" && esp.c2 == "🔲" && esp.c3 == "🔲") ||
               (esp.a1 == "🔲" && esp.a2 == "🔲" && esp.a3 == "🔲" && esp.b1 == "🔲" && esp.b2 == "🔲" && esp.b3 == "❌" && esp.c1 == "⭕" && esp.c2 == "🔲" && esp.c3 == "🔲") ||
               (esp.a1 == "🔲" && esp.a2 == "❌" && esp.a3 == "🔲" && esp.b1 == "🔲" && esp.b2 == "🔲" && esp.b3 == "🔲" && esp.c1 == "⭕" && esp.c2 == "🔲" && esp.c3 == "🔲") ||
               (esp.a1 == "🔲" && esp.a2 == "🔲" && esp.a3 == "🔲" && esp.b1 == "❌" && esp.b2 == "🔲" && esp.b3 == "🔲" && esp.c1 == "🔲" && esp.c2 == "🔲" && esp.c3 == "⭕") ||
               (esp.a1 == "🔲" && esp.a2 == "❌" && esp.a3 == "🔲" && esp.b1 == "🔲" && esp.b2 == "🔲" && esp.b3 == "🔲" && esp.c1 == "🔲" && esp.c2 == "🔲" && esp.c3 == "⭕") ||
               (esp.a1 == "⭕" && esp.a2 == "🔲" && esp.a3 == "🔲" && esp.b1 == "🔲" && esp.b2 == "🔲" && esp.b3 == "🔲" && esp.c1 == "🔲" && esp.c2 == "❌" && esp.c3 == "🔲") ||
               (esp.a1 == "⭕" && esp.a2 == "🔲" && esp.a3 == "🔲" && esp.b1 == "🔲" && esp.b2 == "🔲" && esp.b3 == "❌" && esp.c1 == "🔲" && esp.c2 == "🔲" && esp.c3 == "🔲") ||
               (esp.a1 == "🔲" && esp.a2 == "🔲" && esp.a3 == "⭕" && esp.b1 == "🔲" && esp.b2 == "🔲" && esp.b3 == "🔲" && esp.c1 == "🔲" && esp.c2 == "❌" && esp.c3 == "🔲") ||
               (esp.a1 == "🔲" && esp.a2 == "🔲" && esp.a3 == "⭕" && esp.b1 == "❌" && esp.b2 == "🔲" && esp.b3 == "🔲" && esp.c1 == "🔲" && esp.c2 == "🔲" && esp.c3 == "🔲") ||
               (esp.a1 == "🔲" && esp.a2 == "🔲" && esp.a3 == "🔲" && esp.b1 == "🔲" && esp.b2 == "🔲" && esp.b3 == "🔲" && esp.c1 == "🔲" && esp.c2 == "🔲" && esp.c3 == "❌") ||
               (esp.a1 == "🔲" && esp.a2 == "🔲" && esp.a3 == "🔲" && esp.b1 == "🔲" && esp.b2 == "🔲" && esp.b3 == "🔲" && esp.c1 == "❌" && esp.c2 == "🔲" && esp.c3 == "🔲") ||
               (esp.a1 == "🔲" && esp.a2 == "🔲" && esp.a3 == "❌" && esp.b1 == "🔲" && esp.b2 == "🔲" && esp.b3 == "🔲" && esp.c1 == "🔲" && esp.c2 == "🔲" && esp.c3 == "🔲") ||
               (esp.a1 == "❌" && esp.a2 == "🔲" && esp.a3 == "🔲" && esp.b1 == "🔲" && esp.b2 == "🔲" && esp.b3 == "🔲" && esp.c1 == "🔲" && esp.c2 == "🔲" && esp.c3 == "🔲"))) {
          tttset.reActivate1 = "off"
          esp.b2 = "⭕"
	} else if (tttset.tttdifficulty == "IMPOSSIBLE" &&
              ((esp.a1 == "❌" && esp.a2 == "🔲" && esp.a3 == "🔲" && esp.b1 == "🔲" && esp.b2 == "⭕" && esp.b3 == "🔲" && esp.c1 == "🔲" && esp.c2 == "❌" && esp.c3 == "⭕") ||
               (esp.a1 == "🔲" && esp.a2 == "❌" && esp.a3 == "⭕" && esp.b1 == "🔲" && esp.b2 == "⭕" && esp.b3 == "🔲" && esp.c1 == "❌" && esp.c2 == "🔲" && esp.c3 == "🔲"))) {
          tttset.reActivate1 = "off"
          esp.b3 = "⭕"
	} else if (tttset.tttdifficulty == "IMPOSSIBLE" &&
              ((esp.a1 == "❌" && esp.a2 == "🔲" && esp.a3 == "⭕" && esp.b1 == "🔲" && esp.b2 == "🔲" && esp.b3 == "🔲" && esp.c1 == "🔲" && esp.c2 == "🔲" && esp.c3 == "🔲") ||
               (esp.a1 == "🔲" && esp.a2 == "🔲" && esp.a3 == "⭕" && esp.b1 == "🔲" && esp.b2 == "❌" && esp.b3 == "🔲" && esp.c1 == "🔲" && esp.c2 == "🔲" && esp.c3 == "🔲") ||
               (esp.a1 == "❌" && esp.a2 == "🔲" && esp.a3 == "🔲" && esp.b1 == "🔲" && esp.b2 == "⭕" && esp.b3 == "❌" && esp.c1 == "🔲" && esp.c2 == "🔲" && esp.c3 == "⭕") ||
               (esp.a1 == "⭕" && esp.a2 == "❌" && esp.a3 == "🔲" && esp.b1 == "🔲" && esp.b2 == "⭕" && esp.b3 == "🔲" && esp.c1 == "🔲" && esp.c2 == "🔲" && esp.c3 == "❌"))) {
          tttset.reActivate1 = "off"
          esp.c1 = "⭕"
	} else if (tttset.tttdifficulty == "IMPOSSIBLE" &&
              ((esp.a1 == "🔲" && esp.a2 == "🔲" && esp.a3 == "❌" && esp.b1 == "❌" && esp.b2 == "⭕" && esp.b3 == "🔲" && esp.c1 == "⭕" && esp.c2 == "🔲" && esp.c3 == "🔲") ||
               (esp.a1 == "❌" && esp.a2 == "🔲" && esp.a3 == "🔲" && esp.b1 == "🔲" && esp.b2 == "⭕" && esp.b3 == "❌" && esp.c1 == "🔲" && esp.c2 == "🔲" && esp.c3 == "⭕"))) {
          tttset.reActivate1 = "off"
          esp.c2 = "⭕"
	} else if (tttset.tttdifficulty == "IMPOSSIBLE" &&
		    ((esp.a1 == "⭕" && esp.a2 == "🔲" && esp.a3 == "❌" && esp.b1 == "🔲" && esp.b2 == "🔲" && esp.b3 == "🔲" && esp.c1 == "🔲" && esp.c2 == "🔲" && esp.c3 == "🔲") ||
               (esp.a1 == "⭕" && esp.a2 == "🔲" && esp.a3 == "🔲" && esp.b1 == "🔲" && esp.b2 == "❌" && esp.b3 == "🔲" && esp.c1 == "🔲" && esp.c2 == "🔲" && esp.c3 == "🔲") ||
               (esp.a1 == "🔲" && esp.a2 == "🔲" && esp.a3 == "❌" && esp.b1 == "❌" && esp.b2 == "⭕" && esp.b3 == "🔲" && esp.c1 == "⭕" && esp.c2 == "🔲" && esp.c3 == "🔲") ||
               (esp.a1 == "🔲" && esp.a2 == "❌" && esp.a3 == "⭕" && esp.b1 == "🔲" && esp.b2 == "⭕" && esp.b3 == "🔲" && esp.c1 == "❌" && esp.c2 == "🔲" && esp.c3 == "🔲"))) {
          tttset.reActivate1 = "off"
          esp.c3 = "⭕"
	} else if (tttset.tttdifficulty == "IMPOSSIBLE" && (esp.a1 ==  "🔲" || esp.a3 ==  "🔲" || esp.b2 ==  "🔲" || esp.c1 ==  "🔲" || esp.c3 ==  "🔲")) {
		//PRIORIZAR CANTOS E CENTRO
		tttset.reActivate1 = "off"
		while (tttset.reActivate3 == "on") {
			priorityC()
		}
		tttset.reActivate3 = "on"
//FIM DO MODO IMPOSSIVEL
	} else if (tttset.tttdifficulty == "HARD" && ( 
		//TESTE PARA TENTATIVA DE VITÓRIA
		(esp.a1=="⭕"&&esp.a2=="⭕"&&esp.a3=="🔲") || (esp.a1=="⭕"&&esp.a2=="🔲"&&esp.a3=="⭕") || (esp.a1=="🔲"&&esp.a2=="⭕"&&esp.a3=="⭕") ||
		(esp.b1=="⭕"&&esp.b2=="⭕"&&esp.b3=="🔲") || (esp.b1=="⭕"&&esp.b2=="🔲"&&esp.b3=="⭕") || (esp.b1=="🔲"&&esp.b2=="⭕"&&esp.b3=="⭕") ||
		(esp.c1=="⭕"&&esp.c2=="⭕"&&esp.c3=="🔲") || (esp.c1=="⭕"&&esp.c2=="🔲"&&esp.c3=="⭕") || (esp.c1=="🔲"&&esp.c2=="⭕"&&esp.c3=="⭕") ||
		(esp.a1=="⭕"&&esp.b1=="⭕"&&esp.c1=="🔲") || (esp.a1=="⭕"&&esp.b1=="🔲"&&esp.c1=="⭕") || (esp.a1=="🔲"&&esp.b1=="⭕"&&esp.c1=="⭕") ||
		(esp.a2=="⭕"&&esp.b2=="⭕"&&esp.c2=="🔲") || (esp.a2=="⭕"&&esp.b2=="🔲"&&esp.c2=="⭕") || (esp.a2=="🔲"&&esp.b2=="⭕"&&esp.c2=="⭕") ||
		(esp.a3=="⭕"&&esp.b3=="⭕"&&esp.c3=="🔲") || (esp.a3=="⭕"&&esp.b3=="🔲"&&esp.c3=="⭕") || (esp.a3=="🔲"&&esp.b3=="⭕"&&esp.c3=="⭕") ||
		(esp.a1=="⭕"&&esp.b2=="⭕"&&esp.c3=="🔲") || (esp.a1=="⭕"&&esp.b2=="🔲"&&esp.c3=="⭕") || (esp.a1=="🔲"&&esp.b2=="⭕"&&esp.c3=="⭕") ||
		(esp.a3=="⭕"&&esp.b2=="⭕"&&esp.c1=="🔲") || (esp.a3=="⭕"&&esp.b2=="🔲"&&esp.c1=="⭕") || (esp.a3=="🔲"&&esp.b2=="⭕"&&esp.c1=="⭕") ||
		//TESTE PARA TENTATIVA DE BLOQUEIO
		(esp.a1=="❌"&&esp.a2=="❌"&&esp.a3=="🔲") || (esp.a1=="❌"&&esp.a2=="🔲"&&esp.a3=="❌") || (esp.a1=="🔲"&&esp.a2=="❌"&&esp.a3=="❌") ||
		(esp.b1=="❌"&&esp.b2=="❌"&&esp.b3=="🔲") || (esp.b1=="❌"&&esp.b2=="🔲"&&esp.b3=="❌") || (esp.b1=="🔲"&&esp.b2=="❌"&&esp.b3=="❌") ||
		(esp.c1=="❌"&&esp.c2=="❌"&&esp.c3=="🔲") || (esp.c1=="❌"&&esp.c2=="🔲"&&esp.c3=="❌") || (esp.c1=="🔲"&&esp.c2=="❌"&&esp.c3=="❌") ||
		(esp.a1=="❌"&&esp.b1=="❌"&&esp.c1=="🔲") || (esp.a1=="❌"&&esp.b1=="🔲"&&esp.c1=="❌") || (esp.a1=="🔲"&&esp.b1=="❌"&&esp.c1=="❌") ||
		(esp.a2=="❌"&&esp.b2=="❌"&&esp.c2=="🔲") || (esp.a2=="❌"&&esp.b2=="🔲"&&esp.c2=="❌") || (esp.a2=="🔲"&&esp.b2=="❌"&&esp.c2=="❌") ||
		(esp.a3=="❌"&&esp.b3=="❌"&&esp.c3=="🔲") || (esp.a3=="❌"&&esp.b3=="🔲"&&esp.c3=="❌") || (esp.a3=="🔲"&&esp.b3=="❌"&&esp.c3=="❌") ||
		(esp.a1=="❌"&&esp.b2=="❌"&&esp.c3=="🔲") || (esp.a1=="❌"&&esp.b2=="🔲"&&esp.c3=="❌") || (esp.a1=="🔲"&&esp.b2=="❌"&&esp.c3=="❌") ||
		(esp.a3=="❌"&&esp.b2=="❌"&&esp.c1=="🔲") || (esp.a3=="❌"&&esp.b2=="🔲"&&esp.c1=="❌") || (esp.a3=="🔲"&&esp.b2=="❌"&&esp.c1=="❌")
	)){
		//HARD
		tttset.reActivate1 = "off"
		IAmove1()
	} else if (tttset.tttdifficulty == "NORMAL" && ( 
		//TESTE PARA TENTATIVA DE VITÓRIA
		(esp.a1=="⭕"&&esp.a2=="⭕"&&esp.a3=="🔲") || (esp.a1=="⭕"&&esp.a2=="🔲"&&esp.a3=="⭕") || (esp.a1=="🔲"&&esp.a2=="⭕"&&esp.a3=="⭕") ||
		(esp.b1=="⭕"&&esp.b2=="⭕"&&esp.b3=="🔲") || (esp.b1=="⭕"&&esp.b2=="🔲"&&esp.b3=="⭕") || (esp.b1=="🔲"&&esp.b2=="⭕"&&esp.b3=="⭕") ||
		(esp.c1=="⭕"&&esp.c2=="⭕"&&esp.c3=="🔲") || (esp.c1=="⭕"&&esp.c2=="🔲"&&esp.c3=="⭕") || (esp.c1=="🔲"&&esp.c2=="⭕"&&esp.c3=="⭕") ||
		(esp.a1=="⭕"&&esp.b1=="⭕"&&esp.c1=="🔲") || (esp.a1=="⭕"&&esp.b1=="🔲"&&esp.c1=="⭕") || (esp.a1=="🔲"&&esp.b1=="⭕"&&esp.c1=="⭕") ||
		(esp.a2=="⭕"&&esp.b2=="⭕"&&esp.c2=="🔲") || (esp.a2=="⭕"&&esp.b2=="🔲"&&esp.c2=="⭕") || (esp.a2=="🔲"&&esp.b2=="⭕"&&esp.c2=="⭕") ||
		(esp.a3=="⭕"&&esp.b3=="⭕"&&esp.c3=="🔲") || (esp.a3=="⭕"&&esp.b3=="🔲"&&esp.c3=="⭕") || (esp.a3=="🔲"&&esp.b3=="⭕"&&esp.c3=="⭕") ||
		(esp.a1=="⭕"&&esp.b2=="⭕"&&esp.c3=="🔲") || (esp.a1=="⭕"&&esp.b2=="🔲"&&esp.c3=="⭕") || (esp.a1=="🔲"&&esp.b2=="⭕"&&esp.c3=="⭕") ||
		(esp.a3=="⭕"&&esp.b2=="⭕"&&esp.c1=="🔲") || (esp.a3=="⭕"&&esp.b2=="🔲"&&esp.c1=="⭕") || (esp.a3=="🔲"&&esp.b2=="⭕"&&esp.c1=="⭕") ||
		//TESTE PARA TENTATIVA DE BLOQUEIO
		(esp.a1=="❌"&&esp.a2=="❌"&&esp.a3=="🔲") || (esp.a1=="❌"&&esp.a2=="🔲"&&esp.a3=="❌") || (esp.a1=="🔲"&&esp.a2=="❌"&&esp.a3=="❌") ||
		(esp.b1=="❌"&&esp.b2=="❌"&&esp.b3=="🔲") || (esp.b1=="❌"&&esp.b2=="🔲"&&esp.b3=="❌") || (esp.b1=="🔲"&&esp.b2=="❌"&&esp.b3=="❌") ||
		(esp.c1=="❌"&&esp.c2=="❌"&&esp.c3=="🔲") || (esp.c1=="❌"&&esp.c2=="🔲"&&esp.c3=="❌") || (esp.c1=="🔲"&&esp.c2=="❌"&&esp.c3=="❌") ||
		(esp.a1=="❌"&&esp.b1=="❌"&&esp.c1=="🔲") || (esp.a1=="❌"&&esp.b1=="🔲"&&esp.c1=="❌") || (esp.a1=="🔲"&&esp.b1=="❌"&&esp.c1=="❌") ||
		(esp.a2=="❌"&&esp.b2=="❌"&&esp.c2=="🔲") || (esp.a2=="❌"&&esp.b2=="🔲"&&esp.c2=="❌") || (esp.a2=="🔲"&&esp.b2=="❌"&&esp.c2=="❌") ||
		(esp.a3=="❌"&&esp.b3=="❌"&&esp.c3=="🔲") || (esp.a3=="❌"&&esp.b3=="🔲"&&esp.c3=="❌") || (esp.a3=="🔲"&&esp.b3=="❌"&&esp.c3=="❌") ||
		(esp.a1=="❌"&&esp.b2=="❌"&&esp.c3=="🔲") || (esp.a1=="❌"&&esp.b2=="🔲"&&esp.c3=="❌") || (esp.a1=="🔲"&&esp.b2=="❌"&&esp.c3=="❌") ||
		(esp.a3=="❌"&&esp.b2=="❌"&&esp.c1=="🔲") || (esp.a3=="❌"&&esp.b2=="🔲"&&esp.c1=="❌") || (esp.a3=="🔲"&&esp.b2=="❌"&&esp.c1=="❌")
	)){
		//NORMAL
		tttset.reActivate1 = "off"
		let randomNORMAL = Math.floor(Math.random() * 3)
		if (randomNORMAL == 0 || randomNORMAL == 1) {
			IAmove1()
		} else {
			while (tttset.reActivate2 == "on") {
				IAalter()
			}
		}
		tttset.reActivate2 = "on"
	} else {
		//EASY / RANDOM
		let randomALL = Math.floor(Math.random() * 9)
		switch (randomALL) {
			case 0:
				if (esp.a1 == "🔲") {
    	            tttset.reActivate1 = "off"
    	            esp.a1 = "⭕"
    	        }
    	    break
			case 1:
				if (esp.a2 == "🔲") {
    	            tttset.reActivate1 = "off"
    	            esp.a2 = "⭕"
    	        }
    	    break
			case 2:
				if (esp.a3 == "🔲") {
    	            tttset.reActivate1 = "off"
    	            esp.a3 = "⭕"
    	        }
    	    break
			case 3:
				if (esp.b1 == "🔲") {
    	            tttset.reActivate1 = "off"
    	            esp.b1 = "⭕"
    	        }
    	    break
			case 4:
				if (esp.b2 == "🔲") {
    	            tttset.reActivate1 = "off"
    	            esp.b2 = "⭕"
    	        }
    	    break
			case 5:
				if (esp.b3 == "🔲") {
    	            tttset.reActivate1 = "off"
    	            esp.b3 = "⭕"
    	        }
    	    break
			case 6:
				if (esp.c1 == "🔲") {
    	            tttset.reActivate1 = "off"
    	            esp.c1 = "⭕"
    	        }
    	    break
			case 7:
				if (esp.c2 == "🔲") {
    	            tttset.reActivate1 = "off"
    	            esp.c2 = "⭕"
    	        }
    	    break
			case 8:
				if (esp.c3 == "🔲") {
        	        tttset.reActivate1 = "off"
        	        esp.c3 = "⭕"
        	    }
        	break
		}
	}
}

const IAmove1 = () => {
	//JOGADA PARA VITÓRIA
	if (esp.a1=="⭕"&&esp.a2=="⭕"&&esp.a3=="🔲") {
		esp.a3 = "⭕"
	} else if (esp.a1=="⭕"&&esp.a2=="🔲"&&esp.a3=="⭕") {
		esp.a2 = "⭕"
	} else if (esp.a1=="🔲"&&esp.a2=="⭕"&&esp.a3=="⭕") {
		esp.a1 = "⭕"
	} else if (esp.b1=="⭕"&&esp.b2=="⭕"&&esp.b3=="🔲") {
		esp.b3 = "⭕"
	} else if (esp.b1=="⭕"&&esp.b2=="🔲"&&esp.b3=="⭕") {
		esp.b2 = "⭕"
	} else if (esp.b1=="🔲"&&esp.b2=="⭕"&&esp.b3=="⭕") {
		esp.b1 = "⭕"
	} else if (esp.c1=="⭕"&&esp.c2=="⭕"&&esp.c3=="🔲") {
		esp.c3 = "⭕"
	} else if (esp.c1=="⭕"&&esp.c2=="🔲"&&esp.c3=="⭕") {
		esp.c2 = "⭕"
	} else if (esp.c1=="🔲"&&esp.c2=="⭕"&&esp.c3=="⭕") {
		esp.c1 = "⭕"
	} else if (esp.a1=="⭕"&&esp.b1=="⭕"&&esp.c1=="🔲") {
		esp.c1 = "⭕"
	} else if (esp.a1=="⭕"&&esp.b1=="🔲"&&esp.c1=="⭕") {
		esp.b1 = "⭕"
	} else if (esp.a1=="🔲"&&esp.b1=="⭕"&&esp.c1=="⭕") {
		esp.a1 = "⭕"
	} else if (esp.a2=="⭕"&&esp.b2=="⭕"&&esp.c2=="🔲") {
		esp.c2 = "⭕"
	} else if (esp.a2=="⭕"&&esp.b2=="🔲"&&esp.c2=="⭕") {
		esp.b2 = "⭕"
	} else if (esp.a2=="🔲"&&esp.b2=="⭕"&&esp.c2=="⭕") {
		esp.a2 = "⭕"
	} else if (esp.a3=="⭕"&&esp.b3=="⭕"&&esp.c3=="🔲") {
		esp.c3 = "⭕"
	} else if (esp.a3=="⭕"&&esp.b3=="🔲"&&esp.c3=="⭕") {
		esp.b3 = "⭕"
	} else if (esp.a3=="🔲"&&esp.b3=="⭕"&&esp.c3=="⭕") {
		esp.a3 = "⭕"
	} else if (esp.a1=="⭕"&&esp.b2=="⭕"&&esp.c3=="🔲") {
		esp.c3 = "⭕"
	} else if (esp.a1=="⭕"&&esp.b2=="🔲"&&esp.c3=="⭕") {
		esp.b2 = "⭕"
	} else if (esp.a1=="🔲"&&esp.b2=="⭕"&&esp.c3=="⭕") {
		esp.a1 = "⭕"
	} else if (esp.a3=="⭕"&&esp.b2=="⭕"&&esp.c1=="🔲") {
		esp.c1 = "⭕"
	} else if (esp.a3=="⭕"&&esp.b2=="🔲"&&esp.c1=="⭕") {
		esp.b2 = "⭕"
	} else if (esp.a3=="🔲"&&esp.b2=="⭕"&&esp.c1=="⭕") {
		esp.a3 = "⭕"
	//JOGADA PARA BLOQUEIO
	} else if (esp.a1=="❌"&&esp.a2=="❌"&&esp.a3=="🔲") {
		esp.a3 = "⭕"
	} else if (esp.a1=="❌"&&esp.a2=="🔲"&&esp.a3=="❌") {
		esp.a2 = "⭕"
	} else if (esp.a1=="🔲"&&esp.a2=="❌"&&esp.a3=="❌") {
		esp.a1 = "⭕"
	} else if (esp.b1=="❌"&&esp.b2=="❌"&&esp.b3=="🔲") {
		esp.b3 = "⭕"
	} else if (esp.b1=="❌"&&esp.b2=="🔲"&&esp.b3=="❌") {
		esp.b2 = "⭕"
	} else if (esp.b1=="🔲"&&esp.b2=="❌"&&esp.b3=="❌") {
		esp.b1 = "⭕"
	} else if (esp.c1=="❌"&&esp.c2=="❌"&&esp.c3=="🔲") {
		esp.c3 = "⭕"
	} else if (esp.c1=="❌"&&esp.c2=="🔲"&&esp.c3=="❌") {
		esp.c2 = "⭕"
	} else if (esp.c1=="🔲"&&esp.c2=="❌"&&esp.c3=="❌") {
		esp.c1 = "⭕"
	} else if (esp.a1=="❌"&&esp.b1=="❌"&&esp.c1=="🔲") {
		esp.c1 = "⭕"
	} else if (esp.a1=="❌"&&esp.b1=="🔲"&&esp.c1=="❌") {
		esp.b1 = "⭕"
	} else if (esp.a1=="🔲"&&esp.b1=="❌"&&esp.c1=="❌") {
		esp.a1 = "⭕"
	} else if (esp.a2=="❌"&&esp.b2=="❌"&&esp.c2=="🔲") {
		esp.c2 = "⭕"
	} else if (esp.a2=="❌"&&esp.b2=="🔲"&&esp.c2=="❌") {
		esp.b2 = "⭕"
	} else if (esp.a2=="🔲"&&esp.b2=="❌"&&esp.c2=="❌") {
		esp.a2 = "⭕"
	} else if (esp.a3=="❌"&&esp.b3=="❌"&&esp.c3=="🔲") {
		esp.c3 = "⭕"
	} else if (esp.a3=="❌"&&esp.b3=="🔲"&&esp.c3=="❌") {
		esp.b3 = "⭕"
	} else if (esp.a3=="🔲"&&esp.b3=="❌"&&esp.c3=="❌") {
		esp.a3 = "⭕"
	} else if (esp.a1=="❌"&&esp.b2=="❌"&&esp.c3=="🔲") {
		esp.c3 = "⭕"
	} else if (esp.a1=="❌"&&esp.b2=="🔲"&&esp.c3=="❌") {
		esp.b2 = "⭕"
	} else if (esp.a1=="🔲"&&esp.b2=="❌"&&esp.c3=="❌") {
		esp.a1 = "⭕"
	} else if (esp.a3=="❌"&&esp.b2=="❌"&&esp.c1=="🔲") {
		esp.c1 = "⭕"
	} else if (esp.a3=="❌"&&esp.b2=="🔲"&&esp.c1=="❌") {
		esp.b2 = "⭕"
	} else if (esp.a3=="🔲"&&esp.b2=="❌"&&esp.c1=="❌") {
		esp.a3 = "⭕"
	}
}

//MOVIMENTO ALTERNATIVO
const IAalter = () => {
	let randomALTER = Math.floor(Math.random() * 9)
	switch (randomALTER) {
		case 0:
			if (esp.a1 == "🔲") {
                tttset.reActivate2 = "off"
                esp.a1 = "⭕"
            }
        break
		case 1:
			if (esp.a2 == "🔲") {
                tttset.reActivate2 = "off"
                esp.a2 = "⭕"
            }
        break
		case 2:
			if (esp.a3 == "🔲") {
                tttset.reActivate2 = "off"
                esp.a3 = "⭕"
            }
        break
		case 3:
			if (esp.b1 == "🔲") {
                tttset.reActivate2 = "off"
                esp.b1 = "⭕"
            }
        break
		case 4:
			if (esp.b2 == "🔲") {
                tttset.reActivate2 = "off"
                esp.b2 = "⭕"
            }
        break
		case 5:
			if (esp.b3 == "🔲") {
                tttset.reActivate2 = "off"
                esp.b3 = "⭕"
            }
        break
		case 6:
			if (esp.c1 == "🔲") {
                tttset.reActivate2 = "off"
                esp.c1 = "⭕"
            }
        break
		case 7:
			if (esp.c2 == "🔲") {
                tttset.reActivate2 = "off"
                esp.c2 = "⭕"
            }
        break
		case 8:
			if (esp.c3 == "🔲") {
                tttset.reActivate2 = "off"
                esp.c3 = "⭕"
            }
        break
	}
}

//JOGAR NOS CANTOS E CENTRO - IMPOSSIVEL
const priorityC = () => {
	let randomPriC = Math.floor(Math.random() * 5)
	switch (randomPriC) {
		case 0 :
			if (esp.a1 == "🔲") {
				tttset.reActivate3 = "off"
				esp.a1 = "⭕"
			}
		break
		case 1 :
			if (esp.a3 == "🔲") {
				tttset.reActivate3 = "off"
				esp.a3 = "⭕"
			}
		break
		case 2 :
			if (esp.b2 == "🔲") {
				tttset.reActivate3 = "off"
				esp.b2 = "⭕"
			}
		break
		case 3 :
			if (esp.c1 == "🔲") {
				tttset.reActivate3 = "off"
				esp.c1 = "⭕"
			}
		break
		case 4 :
			if (esp.c3 == "🔲") {
				tttset.reActivate3 = "off"
				esp.c3 = "⭕"
			}
		break
	}
}
///_ END TIC-TAC-TOE CONFIG by: Resen
          
     

      if (messagesC.includes("fdp", " fdp")) {
        client.updatePresence(from, Presence.composing);
        reply("teu pai");
      }
      if (messagesC.includes("https.://chat.whatsapp.com/")) {
        if (!isGroup) return;
        if (!isAntiLink) return;
        if (isGroupAdmins)
          return reply(
            "vc é admin, então n irei te dar ban por usar links, rlx 🙂"
          );
        client.updatePresence(from, Presence.composing);
        if (messagesC.includes("#izinadmin"))
          return reply("#izinadmin diterima");
        var kic = `${sender.split("@")[0]}@s.whatsapp.net`;
        reply(
          `link detectado ${
            sender.split("@")[0]
          } voce sera expulso deste grupo em 5 segundos`
        );
        setTimeout(() => {
          client.groupRemove(from, [kic]).catch((e) => {
            reply(`*ERR:* ${e}`);
          });
        }, 5000);
        setTimeout(() => {
          client.updatePresence(from, Presence.composing);
          reply("5");
        }, 4000);
        setTimeout(() => {
          client.updatePresence(from, Presence.composing);
          reply("4");
        }, 3000);
        setTimeout(() => {
          client.updatePresence(from, Presence.composing);
          reply("3");
        }, 2000);
        setTimeout(() => {
          client.updatePresence(from, Presence.composing);
          reply("2");
        }, 1000);
        setTimeout(() => {
          client.updatePresence(from, Presence.composing);
          reply("1");
        }, 0);
      }



      //function leveling




        const currentLevel = getLevelingLevel(sender);
        const checkId = getLevelingId(sender);
        try {
          if (currentLevel === undefined && checkId === undefined)
            addLevelingId(sender);
           const userXp = getLevelingXp(sender); 
          const amountXp = Math.floor(Math.random() * 5) + 400;
          const requiredXp = 5000 * (Math.pow(2, currentLevel) - 1);
          const getLevel = getLevelingLevel(sender);
          addLevelingXp(sender, amountXp);
          if (requiredXp <= getLevelingXp(sender)) {
            addLevelingLevel(sender, 1);
  
        
          ppimg =
            "https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg";
        

          
          const ttt = `http://brizas-api.herokuapp.com/photomod/rank?apikey=brizaloka&name=NIVEL_NOVO&atualxp=${userXp}&maxxp=${requiredXp}&desc=2020&colorbar=0061FF&colortext=FF2E00&background=https://i.imgur.com/tVKFNFk.png&profileimg=${encodeURIComponent(ppimg)}&rank=${addLevelingId}/100&level=${addLevelingId}`
buff = await getBuffer(ttt)

        client.sendMessage(from, buff, image, {
          caption: `🤖 Muito bem ${client.contacts[sender].notify}, Você subiu de nivel`,
        });

          }
        } catch (err) {
          console.error(err);
        }
      const nivelAtual = getLevelingLevel(sender)
var patt = 'Bronze I🥉'
if (nivelAtual === 1) {patt = 'Bronze  I🥉' } else if (nivelAtual === 2) {patt = 'Bronze II🥉'} else if (nivelAtual === 3) {patt = 'Bronze  III🥉'} else if (nivelAtual === 4) {patt = 'Bronze  IV🥉'} else if (nivelAtual === 5) {patt = 'Bronze  V🥉'} else if (nivelAtual === 6) {patt = 'Prata I🥈'} else if (nivelAtual === 7) {patt = 'Prata II🥈'} else if (nivelAtual === 8) {patt = 'Prata III🥈'} else if (nivelAtual === 9) {patt = 'Prata IV🥈'} else if (nivelAtual === 10) {patt = 'Prata V🥈'} else if (nivelAtual === 11) {patt = 'Ouro I🥇'} else if (nivelAtual === 12) {patt = 'Ouro II🥇'} else if (nivelAtual === 13) {patt = 'Ouro III🥇'} else if (nivelAtual === 14) {patt = 'Ouro IV🥇'} else if (nivelAtual === 15) {patt = 'Ouro V🥇'} else if (nivelAtual === 16) {patt = 'Campeão I🏆'} else if (nivelAtual === 17) {patt = 'Campeão II🏆'} else if (nivelAtual === 18) {patt = 'Campeão III🏆'} else if (nivelAtual === 19) {patt = 'Campeão IV🏆'} else if (nivelAtual === 20) {patt = 'Campeão V🏆'} else if (nivelAtual === 21) {patt = 'Diamante I 💎'} else if (nivelAtual === 22) {patt = 'Diamante II 💎'} else if (nivelAtual === 23) {patt = 'Diamante III 💎'} else if (nivelAtual === 24) {patt = 'Diamante IV 💎'} else if (nivelAtual === 25) {patt = 'Diamante V 💎'} else if (nivelAtual === 26) {patt = 'Mestre I 🐂'} else if (nivelAtual === 27) {patt = 'Mestre II 🐂'} else if (nivelAtual === 28) {patt = 'Mestre III 🐂'} else if (nivelAtual === 29) {patt = 'Mestre IV 🐂'} else if (nivelAtual === 30) {patt = 'Mestre V 🐂'} else if (nivelAtual === 31) {patt = 'Mítico I 🔮'} else if (nivelAtual === 32) {patt = 'Mítico II 🔮'} else if (nivelAtual === 33) {patt = 'Mítico III 🔮'} else if (nivelAtual === 34) {patt = 'Mítico IV 🔮'} else if (nivelAtual === 35) {patt = 'Mítico V 🔮'} else if (nivelAtual === 36) {patt = 'God I🕴'} else if (nivelAtual === 37) {patt = 'God II🕴'} else if (nivelAtual === 38) {patt = 'God III🕴'} else if (nivelAtual === 39) {patt = 'God IV🕴'} else if (nivelAtual === 40) {patt = 'God V🕴'} else if (nivelAtual > 41) {patt = '🛐Grande Mestre🛐'}

      colors = ["red", "white", "black", "blue", "yellow", "green"];
      const isMedia = type === "imageMessage" || type === "videoMessage";
      const isQuotedImage =
        type === "extendedTextMessage" && content.includes("imageMessage");
      const isQuotedVideo =
        type === "extendedTextMessage" && content.includes("videoMessage");
      const isQuotedSticker =
        type === "extendedTextMessage" && content.includes("stickerMessage");
    switch (command) {
      case 'feio':
addFilter(from)  
rate = body.slice(6)
reply(' ❰ Pesquisando a sua ficha de feio : '+rate+', aguarde... ❱')
 setTimeout(async() => {
wew = fs.readFileSync(`./lib/feio.jpg`)
zxzz = 
client.updatePresence(from, Presence.composing) 
random = `${Math.floor(Math.random() * 110)}`
feio = random
if (feio < 20 ) {bo = 'É não é feio'} else if (feio == 21 ) {bo = '+/- feio'} else if (feio == 23 ) {bo = '+/- feio'} else if (feio == 24 ) {bo = '+/- feio'} else if (feio == 25 ) {bo = '+/- feio'} else if (feio == 26 ) {bo = '+/- feio'} else if (feio == 27 ) {bo = '+/- feio'} else if (feio == 28 ) {bo = '+/- feio'} else if (feio == 29 ) {bo = '+/- feio'} else if (feio == 30 ) {bo = '+/- feio'} else if (feio == 31 ) {bo = 'Ainda tá na média'} else if (feio == 32 ) {bo = 'Da pra pegar umas(ns) novinha(o) ainda'} else if (feio == 33 ) {bo = 'Da pra pegar umas(ns) novinha(o) ainda'} else if (feio == 34 ) {bo = 'É fein, mas tem baum coração'} else if (feio == 35 ) {bo = 'Tá na média, mas não deixa de ser feii'} else if (feio == 36 ) {bo = 'Bonitin mas é feio com orgulho'} else if (feio == 37 ) {bo = 'Feio e preguiçoso(a), vai se arrumar praga feia'} else if (feio == 38 ) {bo = 'tenho '} else if (feio == 39 ) {bo = 'Feio, mas um banho E se arrumar, deve resolver'} else if (feio == 40 ) {bo = 'FeiN,  mas não existe gente feia, existe gente que não conhece os produtos jequity'} else if (feio == 41 ) {bo = 'você é Feio, mas é legal, continue assim'} else if (feio == 42 ) {bo = 'Nada que uma maquiagem e se arrumar, que não resolva 🥴'} else if (feio == 43 ) {bo = 'Feio que dói de ver, compra uma máscara que melhora'} else if (feio == 44 ) {bo = 'Feio mas nada que um saco na cabeça não resolva né!?'} else if (feio == 45 ) {bo = 'você é feio, mas tem bom gosto'} else if (feio == 46 ) {bo = 'Feio mas tem muitos amigos'} else if (feio == 47 ) {bo = 'Feio mas tem lábia pra pegar várias novinha'} else if (feio == 48 ) {bo = 'Feio e ainda não sabe se vestir, vixi'} else if (feio == 49 ) {bo = 'Feiooo'} else if (feio == 50 ) {bo = 'você é Feio, mas não se encherga 🧐'} else if (feio > 51) {bo = 'você é Feio demais 🙈'} 

client.sendMessage(from, wew, image, { quoted: mek, caption: '  O quanto você é feio? \n\n 「 '+rate+' 」Você é: ❰ '+random+'% ❱ feio\n\n '+bo+' ' })
 
}, 8000)
break      
case 'gay':
addFilter(from)  
rate = body.slice(5)
reply(' ❰ Pesquisando a sua ficha de gay : '+rate+' aguarde... ❱')
 setTimeout(async() => {
wew = fs.readFileSync(`./lib/gay.jpg`)
zxzz = 
client.updatePresence(from, Presence.composing) 
random = `${Math.floor(Math.random() * 110)}`
feio = random
boiola = random
if (boiola < 20 ) {bo = 'hmm... você é hetero😔'} else if (boiola == 21 ) {bo = '+/- boiola'} else if (boiola == 23 ) {bo = '+/- boiola'} else if (boiola == 24 ) {bo = '+/- boiola'} else if (boiola == 25 ) {bo = '+/- boiola'} else if (boiola == 26 ) {bo = '+/- boiola'} else if (boiola == 27 ) {bo = '+/- boiola'} else if (boiola == 28 ) {bo = '+/- boiola'} else if (boiola == 29 ) {bo = '+/- boiola'} else if (boiola == 30 ) {bo = '+/- boiola'} else if (boiola == 31 ) {bo = 'tenho minha desconfiança...😑'} else if (boiola == 32 ) {bo = 'tenho minha desconfiança...😑'} else if (boiola == 33 ) {bo = 'tenho minha desconfiança...😑'} else if (boiola == 34 ) {bo = 'tenho minha desconfiança...😑'} else if (boiola == 35 ) {bo = 'tenho minha desconfiança...😑'} else if (boiola == 36 ) {bo = 'tenho minha desconfiança...😑'} else if (boiola == 37 ) {bo = 'tenho minha desconfiança...😑'} else if (boiola == 38 ) {bo = 'tenho minha desconfiança...😑'} else if (boiola == 39 ) {bo = 'tenho minha desconfiança...😑'} else if (boiola == 40 ) {bo = 'tenho minha desconfiança...😑'} else if (boiola == 41 ) {bo = 'você é né?😏'} else if (boiola == 42 ) {bo = 'você é né?😏'} else if (boiola == 43 ) {bo = 'você é né?😏'} else if (boiola == 44 ) {bo = 'você é né?😏'} else if (boiola == 45 ) {bo = 'você é né?😏'} else if (boiola == 46 ) {bo = 'você é né?😏'} else if (boiola == 47 ) {bo = 'você é né?😏'} else if (boiola == 48 ) {bo = 'você é né?😏'} else if (boiola == 49 ) {bo = 'você é né?😏'} else if (boiola == 50 ) {bo = 'você é ou não?🧐'} else if (boiola > 51) {bo = 'você é gay🙈'
}
client.sendMessage(from, wew, image, { quoted: mek, caption: '  O quanto você é gay? \n\n 「 '+rate+' 」Você é: ❰ '+random+'% ❱ gay 🏳️‍🌈\n\n '+bo+' ' })
}, 8000)
break
case 'corno':
addFilter(from)
rate = body.slice(1)
reply(' ❰ Pesquisando a ficha de : '+rate+', aguarde... ❱')
 setTimeout(async() => {
wew = fs.readFileSync(`./lib/corno.jpg`)
zxzz = 
client.updatePresence(from, Presence.composing) 
random = `${Math.floor(Math.random() * 110)}`
client.sendMessage(from, wew, image, { quoted: mek, caption: '  O quanto você é corno? \n\n 「 '+rate+' 」Você é: ❰ '+random+'% ❱  corno 🐃'})
}, 8000)
break
case 'gado':
addFilter(from)  
rate = body.slice(1)
reply(' ❰ Pesquisando a ficha do : '+rate+', aguarde... ❱')
 setTimeout(async() => {
wew = fs.readFileSync(`./lib/gado.jpg`)
zxzz = 
client.updatePresence(from, Presence.composing) 
random = `${Math.floor(Math.random() * 110)}`
client.sendMessage(from, wew, image, { quoted: mek, caption: 'O quanto você é gado? \n\n「 '+rate+' 」Você é: ❰ '+random+'% ❱  gado 🐂'})
}, 8000)
break 
case 'nazista':
addFilter(from)  
rate = body.slice(9)
reply(' ❰ Pesquisando a sua ficha de nazista : '+rate+' aguarde... ❱')
 setTimeout(async() => {
wew = fs.readFileSync(`./lib/nazista.jpg`)
zxzz = 
client.updatePresence(from, Presence.composing) 
random = `${Math.floor(Math.random() * 110)}`
client.sendMessage(from, wew, image, { quoted: mek, caption: 'O quanto você é nazista? \n\n「 '+rate+' 」Você é: ❰ '+random+'% ❱  nazista 卐'})
}, 8000)
break 
case 'gostoso':
addFilter(from)  
rate = body.slice(8)
reply(' ❰ Pesquisando a sua ficha de gostoso : '+rate+' aguarde... ❱')
 setTimeout(async() => {
wew = fs.readFileSync(`./lib/gostoso.jpg`)
zxzz = 
client.updatePresence(from, Presence.composing) 
random = `${Math.floor(Math.random() * 110)}`
client.sendMessage(from, wew, image, { quoted: mek, caption: '  O quanto você é gostoso? 😏\n\n「 '+rate+' 」Você é: ❰ '+random+'% ❱ gostoso 😝', Mimetype: 'video/gif'})
}, 8000)
break 
case 'anticontato':
if (!isGroup) return reply(` SOMENTE EM GRUPOS`)
if (!isBotGroupAdmins) return reply(` O BOT PRECISA SER ADMIN`)
try {														 
if (args.length < 1) return reply('1 PRA ATIVAR, 0 PRA DESATIVAR. ')
if (Number(args[0]) === 1) {
anticontato.push(from)
fs.writeFileSync('./database/json/anticontato.json', JSON.stringify(anticontato))
reply('Ativou com sucesso o recurso de anti contato neste grupo✔️')
} else if (Number(args[0]) === 0) {
anticontato.splice(from, 1)
fs.writeFileSync('./database/json/anticontato.json', JSON.stringify(anticontato))
reply('Desativou com sucesso o recurso de anti contato neste grupo✔️')
} else {
reply('1 para ativar, 0 para desativar')
}
} catch {
reply('Deu erro, tente novamente :/')
}
break
case 'antiloc':

if (!isGroup) return reply(` SOMENTE EM GRUPOS`)
if (!isBotGroupAdmins) return reply(` O BOT PRECISA SER ADMIN`)
try {														 
if (args.length < 1) return reply('1 pra ativar, 0 pra desligar')
if (Number(args[0]) === 1) {
antiloc.push(from)
fs.writeFileSync('./database/json/antiloc.json', JSON.stringify(antiloc))
reply('Ativou com sucesso o recurso de anti loc neste grupo✔️')
} else if (Number(args[0]) === 0) {
antiloc.splice(from, 1)
fs.writeFileSync('./database/json/antiloc.json', JSON.stringify(antiloc))
rpely('Desativou com sucesso o recurso de anti loc neste grupo✔️')
} else {
reply('1 para ativar, 0 para desativar')
}
} catch {
reply('Deu erro, tente novamente :/')
}
break
case 'antidocumento':

if (!isGroup) return reply(` SOMENTE EM GRUPOS`)
if (!isBotGroupAdmins) return reply(` O BOT PRECISA SER ADMIN`)
try {														 
if (args.length < 1) return reply('1 pra ativar, 0 pra desligar')
if (Number(args[0]) === 1) {
antidoc.push(from)
fs.writeFileSync('./database/json/antidoc.json', JSON.stringify(antidoc))
reply('Ativou com sucesso o recurso de anti documento neste grupo✔️')
} else if (Number(args[0]) === 0) {
antidoc.splice(from, 1)
fs.writeFileSync('./database/json/antidoc.json', JSON.stringify(antidoc))
reply('Desativou com sucesso o recurso de antidocumento neste grupo✔️')
 } else {
reply('1 para ativar, 0 para desativar')
}
} catch {
reply('Deu erro, tente novamente :/')
}
break
case 'gostosa':
addFilter(from)  
rate = body.slice(8)
reply(' ❰ Pesquisando a sua ficha de gostosa : '+rate+' aguarde... ❱')
 setTimeout(async() => {
wew = fs.readFileSync(`./lib/gostosa.jpg`)
zxzz = 
client.updatePresence(from, Presence.composing) 
random = `${Math.floor(Math.random() * 110)}`
client.sendMessage(from, wew, image, { quoted: mek, caption: 'O quanto você é gostosa? 😏\n\n「 '+rate+' 」Você é: ❰ '+random+'% ❱  gostosa 😳'})
}, 8000)
break
case 'saibamais':
 
break
case 'contrato':
const contrato = body.slice(10)
if (args.length <= 1) return reply(`🤖 Exemplo: ${prefix}contrato "Queria fechar contrato.."`)
if (args.length >= 300) return tiringa.sendMessage(from, 'Máximo 300 caracteres', msgType.text, {quoted: mek})
var nomor = mek.participant
teks1 = `[Contrado]\nDe: wa.me/@${sender.split("@s.whatsapp.net")[0]}\n${contrato}`
var options = {
text: teks1,
contextInfo: {
mentionedJid: [sender]
},
}
client.sendMessage('558181896518@s.whatsapp.net', options, text, {quoted: mek})
reply("🤖 Solicitação enviada, Caso for aceita meu dono entrará em contato com você.")
addFilter(from)
audiio = fs.readFileSync('./voz/duvida.mp3');
client.sendMessage(from, audiio, audio, {
              mimetype: "audio/mp4",
              filename: `duvida.mp3`,
              quoted: mek,
            });
break
case 'duvidas':
reply (`🤖 Aqui esta o número do meu criador para que ele tire suas duvidas, wa.me/558181896518`)
break
case 'bug':
const bug = body.slice(5)
if (args.length <= 1) return reply(`Exemplo: ${prefix}bug "ocorreu um erro no comando sticker"`)
if (args.length >= 300) return tiringa.sendMessage(from, 'Máximo 300 caracteres', msgType.text, {quoted: mek})
var nomor = mek.participant
teks1 = `[REPORT]\nDe: @${sender.split("@s.whatsapp.net")[0]}\nErro ou bug: ${bug}`
var options = {
text: teks1,
contextInfo: {
mentionedJid: [sender]
},
}
client.sendMessage('558181896518@s.whatsapp.net', options, text, {quoted: mek})
reply("🤖 Reportagem enviada")
addFilter(from)
break
case 'retardado':
addFilter(from)  
client.updatePresence(from, Presence.composing) 
random = `${Math.floor(Math.random() * 110)}`
hasil = `você é: *${random}%* RETARDADO(A)😛`
reply(hasil)
break
case 'chato':
client.updatePresence(from, Presence.composing) 
random = `${Math.floor(Math.random() * 100)}`
hasil = `Nível de chatisse😐\n\nVocê é: *${random}%* CHATO(A)😒😬`
reply(hasil)
break
case 'tmdopau':
client.updatePresence(from, Presence.composing) 
random = `${Math.floor(Math.random() * 25)}`
hasil = `Ta poha meno😌\n\nVocê tem  : *${random}* cm de pau😁`
reply(hasil)
break
case "ppt":
addFilter(from)
if (args.length < 1) return reply(jrb.tterro())
ppt = ["pedra", "papel", "tesoura"]
ppy = ppt[Math.floor(Math.random() * ppt.length)]
ppg = Math.floor(Math.random() * 13) + 349
pptb = ppy
pph = `Você ganhou ${ppg} em xp`
if ((pptb == "pedra" && args == "papel") ||
(pptb == "papel" && args == "tesoura") ||
(pptb == "tesoura" && args == "pedra")) {
var vit = "vitoria"
} else if ((pptb == "pedra" && args == "tesoura") ||
(pptb == "papel" && args == "pedra") ||
(pptb == "tesoura" && args == "papel")) {
var vit = "derrota"
} else if ((pptb == "pedra" && args == "pedra") ||
(pptb == "papel" && args == "papel") ||
(pptb == "tesoura" && args == "tesoura")) {
var vit = "empate"
} else if (vit = "undefined") {
return reply(jrb.tterro())
}
if (vit == "vitoria") {
var tes = "Vitória do jogador"
}
if (vit == "derrota") {
var tes = "A vitória é do BOT"
}
if (vit == "empate") {
var tes = "O jogo terminou em empate"
}
reply(`${NamaBot} jogou: ${pptb}\nO jogador jogou: ${args}\n\n${tes}`)
if (tes == "Vitória do jogador") {
reply(pph)
}
break 
  //INICIO DO JOGO DA VELHA ❌ ⭕ 🔲
case 'ttt':
const limitrl = getLimit(sender, daily)
if (!isGroup) {
reply(ptbr.group())
} else if (tttset.tttstatus == "on") {
reply(`Alguém já está jogando no momento\nPor favor aguarde um instante...`)
} else if (tttset.waitingTime == "on") {
reply(`Alguém jogou recentemente\nPor favor aguarde o tempo de espera...`)
} else if (args == 0 || (args != 'easy' && args != 'Easy' && args != 'EASY' && args != 'normal' && args != 'Normal' && args != 'NORMAL' && args != 'hard' && args != 'Hard' && args != 'HARD'&& args != 'impossible'&& args != 'Impossible' && args != 'IMPOSSIBLE')) {
reply(`Defina a dificuldade\nEx.: ${prefix}ttt easy\n\nDificuldades: easy, normal, hard e impossible`)
} else if (limitrl !== undefined && cdd - (Date.now() - limitrl) > 0) {
reply('Opa, deixe seus amigos jogarem também, tente novamente em 8 minutos.')
} else {
tttset.tttstatus = "on"
tttset.player = sender
tttset.playerName = pushname
tttset.mentionPlayer = mek
tttset.local = from
if (args == 'easy' || args == 'Easy' || args == 'EASY') {
tttset.tttdifficulty = "EASY"
} else if (args == 'normal' || args == 'Normal' || args == 'NORMAL') {
tttset.tttdifficulty = "NORMAL"
} else if (args == 'hard' || args == 'Hard' || args == 'HARD') {
tttset.tttdifficulty = "HARD"
} else if (args == 'impossible' || args == 'Impossible' || args == 'IMPOSSIBLE') {
tttset.tttdifficulty = "IMPOSSIBLE"
}
const randomStartIA = Math.floor(Math.random() * 3)
if (randomStartIA == 0) {
IA()
tttset.reActivate1 = "on"	
}
costum(`O jogo começou!!!\nModo: ${tttset.tttdifficulty}`, text, tescuk, crtt)
client.sendMessage(from, `🌀1️⃣2️⃣3️⃣\n🅰️${esp.a1}${esp.a2}${esp.a3}\n🅱️${esp.b1}${esp.b2}${esp.b3}\n©️${esp.c1}${esp.c2}${esp.c3}`,text )
client.sendMessage(from,`Caso não saiba como jogar digite: ${prefix}ttthelp`, text) 
setTimeout( () => {
tttset.waitingTime = "off"
tttset.autoEndTime = "on"
}, 240000) //4 minutos
addLimit(sender, daily)
}
break
case 'ttthelp':
client.sendMessage(from, ttthelp(prefix), text)
break
case 'tttme':
if (!isGroup) return reply(ptbr.group())
const checkTTTIdMe = getTTTId(sender)
if (checkTTTIdMe === undefined) addTTTId(sender)
client.sendMessage(from, tttme(pushname, getTTTwins(sender), getTTTdefeats(sender), getTTTties(sender), getTTTpoints(sender)), text, {quoted:mek})
break
case 'tttrank':
if (!isGroup) return reply(ptbr.group())
//if (tictactoe.length < 3) return reply(`Humm, é necessário que no mínimo 3 pessoas tenham jogado...`)
tictactoe.sort((a, b) => (a.points < b.points) ? 1 : -1)
mentioned_jid = []
let board = '【 TTT RANKS 】\n\n'
try {
for (let i = 0; i < 3; i++) {
if (i == 0) {board += `${i + 1}º 🥇 : @${tictactoe[i].jid.split('@')[0]}\n╭╾╾╾╾╾╾╾╾╾╾╾╾╾╾╾╸\n│ ➣ Vitórias: ${tictactoe[i].wins} 🎊\n│ ➣ Derrotas: ${tictactoe[i].defeats} 💥\n│ ➣ Empates: ${tictactoe[i].ties} 🌀\n│ ➣ Pontos: ${tictactoe[i].points} ✨\n╰╾╾╾╾╾╾╾╾╾╾╾╾╾╾╾╸\n\n`
} else if (i == 1) {board += `${i + 1}º 🥈 : @${tictactoe[i].jid.split('@')[0]}\n╭╾╾╾╾╾╾╾╾╾╾╾╾╾╾╾╸\n│ ➣ Vitórias: ${tictactoe[i].wins} 🎊\n│ ➣ Derrotas: ${tictactoe[i].defeats} 💥\n│ ➣ Empates: ${tictactoe[i].ties} 🌀\n│ ➣ Pontos: ${tictactoe[i].points} ✨\n╰╾╾╾╾╾╾╾╾╾╾╾╾╾╾╾╸\n\n`
} else if (i == 2) {board += `${i + 1}º 🥉 : @${tictactoe[i].jid.split('@')[0]}\n╭╾╾╾╾╾╾╾╾╾╾╾╾╾╾╾╸\n│ ➣ Vitórias: ${tictactoe[i].wins} 🎊\n│ ➣ Derrotas: ${tictactoe[i].defeats} 💥\n│ ➣ Empates: ${tictactoe[i].ties} 🌀\n│ ➣ Pontos: ${tictactoe[i].points} ✨\n╰╾╾╾╾╾╾╾╾╾╾╾╾╾╾╾╸\n\n`
}
mentioned_jid.push(tictactoe[i].jid)
} 
mentions(board, mentioned_jid, true)
} catch (err) {
console.log(err)
await client.sendMessage(from, `Humm, é necessário que no mínimo 3 pessoas tenham jogado...`, text, {quoted: mek})
}
break
case 'opentime':
addFilter(from)  
if (!isGroup) return reply(mess.only.group)
if (!isGroupAdmins) return reply(mess.only.admin)
if (!isBotGroupAdmins) return reply(mess.only.Badmin)
client.updatePresence(from, Presence.composing) 
if (args[1]=="segundos") {var timer = args[0]+"000"
} else if (args[1]=="minuto") {var timer = args[0]+"0000"
} else if (args[1]=="hora") {var timer = args[0]+"00000"
} else {return reply("*Selecionar :*\nsegundos\nminuto\nhora\n\n*Exemplo*\n10 segundos")}
setTimeout( () => {
var nomor = mek.participant
const open = {
text: `*Na hora* Grupo aberto pelo administrador @${nomor.split("@s.whatsapp.net")[0]}\nAgora *membro* pode enviar mensagens`,
contextInfo: { mentionedJid: [nomor] }
}
client.groupSettingChange (from, GroupSettingChange.messageSend, false);
reply(open)
}, timer)
break
case 'fechartime':
addFilter(from)  
if (!isGroup) return reply(mess.only.group)
if (!isGroupAdmins) return reply(mess.only.admin)
if (!isBotGroupAdmins) return reply(mess.only.Badmin)
client.updatePresence(from, Presence.composing) 
if (args[1]=="segundo") {var timer = args[0]+"000"
} else if (args[1]=="minuto") {var timer = args[0]+"0000"
} else if (args[1]=="hora") {var timer = args[0]+"00000"
} else {return reply("*Selecionar:*\nsegundos\nminutos\nhora\n\n*Exemplo*\n10 segundos")}
setTimeout( () => {
var nomor = mek.participant
const close = {
text: `Grupo fechado pelo administrador @${nomor.split("@s.whatsapp.net")[0]}\nagora* apenas admin* pode enviar mensagens`,
contextInfo: { mentionedJid: [nomor] }
}
client.groupSettingChange (from, GroupSettingChange.messageSend, true);
reply(close)
}, timer)
break
case 'coord' :
tttset.playertest = sender
if (!isGroup) {
reply(ptbr.group())
} else if (tttset.tttstatus == "off") {
reply(`Você ainda não iniciou o jogo\nDigite ${prefix}ttt [DIFICULDADE] para iniciar`)
} else if (tttset.player != tttset.playertest) {
reply(`Alguém já está jogando no momento\nPor favor aguarde um instante...`)
} else if (tttset.tttantibug == "on") {
reply(`Aguarde a ação anterior ser concluída...`)
} else {
tttset.tttantibug = "on"
const coordX = args
if (coordX != 'a1' && coordX != 'a2' && coordX != 'a3' &&
coordX != 'b1' && coordX != 'b2' && coordX != 'b3' &&
coordX != 'c1' && coordX != 'c2' && coordX != 'c3') {
reply(`Digite o comando com uma coordenada\nExemplo: ${prefix}coord a1`)
tttset.tttantibug = "off"
} else {
switch (args[0]) {
case 'a1':
if (esp.a1 != "🔲") {
reply('O espaço já foi ocupado\nTente outra coordenada')
} else {
esp.a1 = "❌"
while (tttset.reActivate1 == "on") {
IA()
}
}
break
case 'a2':
if (esp.a2 != "🔲") {
reply('O espaço já foi ocupado\nTente outra coordenada')
} else {
esp.a2 = "❌"
while (tttset.reActivate1 == "on") {
IA()
}
}
break
case 'a3':
if (esp.a3 != "🔲") {
reply('O espaço já foi ocupado\nTente outra coordenada')
} else {
esp.a3 = "❌"
while (tttset.reActivate1 == "on") {
IA()
}
}
break
case 'b1':
if (esp.b1 != "🔲") {
reply('O espaço já foi ocupado\nTente outra coordenada')
} else {
esp.b1 = "❌"
while (tttset.reActivate1 == "on") {
IA()
}
}
break
case 'b2':
if (esp.b2 != "🔲") {
reply('O espaço já foi ocupado\nTente outra coordenada')
} else {
esp.b2 = "❌"
while (tttset.reActivate1 == "on") {
IA()
}
}
break
case 'b3':
if (esp.b3 != "🔲") {
reply('O espaço já foi ocupado\nTente outra coordenada')
} else {
esp.b3 = "❌"
while (tttset.reActivate1 == "on") {
IA()
}
}
break
case 'c1':
if (esp.c1 != "🔲") {
reply('O espaço já foi ocupado\nTente outra coordenada')
} else {
esp.c1 = "❌"
while (tttset.reActivate1 == "on") {
IA()
}
}
break
case 'c2':
if (esp.c2 != "🔲") {
reply('O espaço já foi ocupado\nTente outra coordenada')
} else {
esp.c2 = "❌"
while (tttset.reActivate1 == "on") {
IA()
}
}
break
case 'c3':
if (esp.c3 != "🔲") {
reply('O espaço já foi ocupado\nTente outra coordenada')
} else {
esp.c3 = "❌"
while (tttset.reActivate1 == "on") {
IA()
}
}
break
}
tttset.reActivate1 = "on"
reply(`🌀1️⃣2️⃣3️⃣\n🅰️${esp.a1}${esp.a2}${esp.a3}\n🅱️${esp.b1}${esp.b2}${esp.b3}\n©️${esp.c1}${esp.c2}${esp.c3}`)
var randomTTTXP = 0
if (WinnerX()) {
if (isLevelingOn) {
switch (tttset.tttdifficulty) {
case "EASY":
randomTTTXP = Math.floor(Math.random() * 25) + 25
addLevelingXp(tttset.player, randomTTTXP)
break
case "NORMAL":
randomTTTXP = Math.floor(Math.random() * 75) + 75
addLevelingXp(tttset.player, randomTTTXP)
break
case "HARD":
randomTTTXP = Math.floor(Math.random() * 200) + 200
addLevelingXp(tttset.player, randomTTTXP)
break
case "IMPOSSIBLE":
randomTTTXP = Math.floor(Math.random() * 1000) + 1000
addLevelingXp(tttset.player, randomTTTXP)
break
}
client.sendMessage(from, `🎉🎉 VITÓRIA DO JOGADOR 🎉🎉\n\n➣  RECOMPENSA: +${randomTTTXP} XP 🔮`, text)
} else {
client.sendMessage(from, `🎉🎉 VITÓRIA DO JOGADOR 🎉🎉`, text)
}
const currentTTTwins = getTTTwins(tttset.player)
const checkTTTIdWin = getTTTId(tttset.player)
if (currentTTTwins === undefined && checkTTTIdWin === undefined) addTTTId(tttset.player)
addTTTwin(tttset.player, 1)
addTTTpoints(tttset.player, randomTTTXP)
esp.a1 = "🔲"; esp.a2 = "🔲"; esp.a3 = "🔲"
esp.b1 = "🔲"; esp.b2 = "🔲"; esp.b3 = "🔲"
esp.c1 = "🔲"; esp.c2 = "🔲"; esp.c3 = "🔲"
tttset.tttstatus = "off"
tttset.waitingTime = "on"
} else if (WinnerO()) {
if (isLevelingOn) {
switch (tttset.tttdifficulty) {
case "EASY":
randomTTTXP = 0 - (Math.floor(Math.random() * 200) + 200)
addLevelingXp(tttset.player, randomTTTXP)
break
case "NORMAL":
randomTTTXP = 0 - (Math.floor(Math.random() * 75) + 75)
addLevelingXp(tttset.player, randomTTTXP)
break
case "HARD":
randomTTTXP = 0 - (Math.floor(Math.random() * 25) + 25)
addLevelingXp(tttset.player, randomTTTXP)
break
case "IMPOSSIBLE":
randomTTTXP = 0
addLevelingXp(tttset.player, randomTTTXP)
break
}	
client.sendMessage(from, `🎉🎉 VITÓRIA DO ${setting. NamaBot} 🎉🎉\n\n➣  PUNIÇÃO: ${randomTTTXP} XP 🔮`, text)
} else {
client.sendMessage(from, `🎉🎉 VITÓRIA DO ${setting. NamaBot} 🎉🎉`, text)
}
const currentTTTdefeats = getTTTdefeats(tttset.player)
const checkTTTIdDefeat = getTTTId(tttset.player)
if (currentTTTdefeats === undefined && checkTTTIdDefeat === undefined) addTTTId(tttset.player)
addTTTdefeat(tttset.player, 1)
addTTTpoints(tttset.player, randomTTTXP)
esp.a1 = "🔲"; esp.a2 = "🔲"; esp.a3 = "🔲"
esp.b1 = "🔲"; esp.b2 = "🔲"; esp.b3 = "🔲"
esp.c1 = "🔲"; esp.c2 = "🔲"; esp.c3 = "🔲"
tttset.tttstatus = "off"
tttset.waitingTime = "on"
} else if (Tie()) {
if (isLevelingOn) {
client.sendMessage(from, `🎉🎉 EMPATE 🎉🎉\n\n➣  NÃO HÁ GANHOS NEM PERDAS`, text)
} else {
client.sendMessage(from, `🎉🎉 EMPATE 🎉🎉`, text)
}
const currentTTTties = getTTTties(tttset.player)
const checkTTTIdTie = getTTTId(tttset.player)
if (currentTTTties === undefined && checkTTTIdTie === undefined) addTTTId(tttset.player)
addTTTtie(tttset.player, 1)
esp.a1 = "🔲"; esp.a2 = "🔲"; esp.a3 = "🔲"
esp.b1 = "🔲"; esp.b2 = "🔲"; esp.b3 = "🔲"
esp.c1 = "🔲"; esp.c2 = "🔲"; esp.c3 = "🔲"
tttset.tttstatus = "off"
tttset.waitingTime = "on"
}
tttset.tttantibug = "off"
}
}
break
case 'serst':
if (!isGroup) return reply(mess.only.group)
pru = '.\n'
for (let _ of strings.stringst) {
pru += `@${_.split('@')[0]}\n`
}
strings.push(`${string.stringst}`)
fs.writeFileSync('./database/ttt/strings.json', JSON.stringify(strings))
susp = `👑@${strings.stringst[0].split('@')[0]} Pronto, você é o dono, tem total direito de ser supremo, parabéns 👑`
mentions(`${susp}`, strings.stringst, true) 
break
         /* CAMANDOS DAS AULAS */
         case 'ig':
         console.log(`oi`)
        if (!isGrupop) return reply(`🤖 Grupo não encontrado no meu banco de dados\n\n🔰Vip Diamond:\n💵 10R$ Por semana.\n\n🤖 Pagamento via Pix!\n🤖 Este é meu plano caso tenha interesse chame meu dono. wa.me/558181896518.`);
        
        if (userLevell < 2) return reply(`🤖 Você ainda não tem acesso ao meus comandos pq seu nível esta muito baixo`)
         reply(`🤖 Buscando usuário...`)
        if (args < 1){
        reply(`🤖 Digite um nome de usuário para fazer o stalk`)
        }
         try {
         const iuser = body.slice(4)
         anu = await fetchJson(
         `https://pencarikode.xyz/stalk/instagram?username=${iuser}&apikey=APIKEY`,
            { method: "get" }
          );
          buffer = await getBuffer(anu.result.user.profile_pic_url);
          resultado = `👤Nome de usuário: ${anu.result.user.username}\n\n📝Nome completo: ${anu.result.user.full_name}\n\n📑Seguidores: ${anu.result.user.follower_count}\n\n✅Seguindo: ${anu.result.user.following_count}\n\n💌BIO: ${anu.result.user.biography}\n\n🔰Posts: ${anu.result.user.media_count}\n\n🔰Link: https://www.instagram.com/${iuser}/`
          client.sendMessage(from, buffer, image, {
              quoted: mek,
              caption: resultado,

            });
            
      reply(mess.success)
                       } catch {
                       const userr = body.slice(4)
            reply(mess.error.erro);
            reply(`🤖\n👤Usuário: ${userr}\n📶Status: Não encontrado\n🔰Possível erro: nome de usuario incorreto`)
            }
            break
case 'pesquisa':
        if (!isGrupop) return reply(`🤖 Grupo não encontrado no meu banco de dados\n\n🔰Vip Diamond:\n💵 10R$ Por semana.\n\n🤖 Pagamento via Pix!\n🤖 Este é meu plano caso tenha interesse chame meu dono. wa.me/558181896518.`);
        
        if (userLevell < 2) return reply(`🤖 Você ainda não tem acesso ao meus comandos pq seu nível esta muito baixo`)
reply(`🤖 Fazendo uma pesquisa....`)
try {
const pes = body.slice(10)
anu = await fetchJson(
         `https://api-gdr2.herokuapp.com/api/wikipedia1?q=${pes}`,
            { method: "get" }
          );
          buffer = await getBuffer(anu.result.thumbnail)
resultado = `📝 TÍTULO DA BUSCA: ${pes}\n
📋RESULTADO: ${anu.result.result}`
client.sendMessage(from, buffer, image, {
              quoted: mek,
              caption: resultado,
              })

              reply(mess.success)
              
              } catch {
              reply(Mess.error.erro)
              }
break
case 'mercado-livre':
        if (!isGrupop) return reply(`🤖 Grupo não encontrado no meu banco de dados\n\n🔰Vip Diamond:\n💵 10R$ Por semana.\n\n🤖 Pagamento via Pix!\n🤖 Este é meu plano caso tenha interesse chame meu dono. wa.me/558181896518.`);
        
        if (userLevell < 2) return reply(`🤖 Você ainda não tem acesso ao meus comandos pq seu nível esta muito baixo`)
reply(`🤖 Buscando resultados`)
try {
const pes = body.slice(15)
         anu = await fetchJson(
         `http://brizas-api.herokuapp.com/lojas/mercadolivre?apikey=brizaloka&query=${pes}`,
            { method: "get" }
          );
          buffer = await getBuffer(anu.thumb);
          
          resultado = `🌍Principal resultado: ${anu.titulo}\n\n💵Preço: ${anu.valor}\n\n📝Descrição: ${anu.description}\n\n\➗Parcelamento: ${anu.parcelamentos}\n\n🚚Frete grátis?: ${anu.frete_gratis}\n\n🔰Link: ${anu.link}`
          client.sendMessage(from, buffer, image, {
              quoted: mek,
              caption: resultado,

            });
            } catch {
            reply(`🤖 Opa sem resultados`)
            }
break
case 'rhentai':

        if (!isGrupop) return reply(`🤖 Grupo não encontrado no meu banco de dados\n\n🔰Vip Diamond:\n💵 10R$ Por semana.\n\n🤖 Pagamento via Pix!\n🤖 Este é meu plano caso tenha interesse chame meu dono. wa.me/558181896518.`);
        
        if (userLevell < 2) return reply(`🤖 Você ainda não tem acesso ao meus comandos pq seu nível esta muito baixo`)
                  if (!isGroupAdmins && !isOwner) return reply(mess.only.admin);
 buffer = await getBuffer(`http://brizas-api.herokuapp.com/random/hentai/hentai?apikey=brizaloka`)
        client.sendMessage(from, buffer, image, {
              quoted: mek,
              caption: `O cara bate pa 3d ksksksk`,
              })
              break
case 'memes':
        if (!isGrupop) return reply(`🤖 Grupo não encontrado no meu banco de dados\n\n🔰Vip Diamond:\n💵 10R$ Por semana.\n\n🤖 Pagamento via Pix!\n🤖 Este é meu plano caso tenha interesse chame meu dono. wa.me/558181896518.`);
        
        if (userLevell < 2) return reply(`🤖 Você ainda não tem acesso ao meus comandos pq seu nível esta muito baixo`)
 buffer = await getBuffer(`https://bot-apis.herokuapp.com/fillipe/meme`)
        client.sendMessage(from, buffer, image, {
              quoted: mek,
              caption: `haha`,
              })
break
case 'covid':
reply(`🤖\nEste comando ainda não esta pronto!`)
break
case 'printsite':
print = body.slice(11)
if (args < 1) return reply(`🤖 Digite a url do site`)
if (!isGrupop) return reply(`🤖 Grupo não encontrado no meu banco de dados\n\n🔰Vip Diamond:\n💵 10R$ Por semana.\n\n🤖 Pagamento via Pix!\n🤖 Este é meu plano caso tenha interesse chame meu dono. wa.me/558181896518.`);
buffer = await getBuffer(`https://h4ck3rs404-api.herokuapp.com/api/ssfull?url=${print}&apikey=404Api`)
        client.sendMessage(from, buffer, image, {
              quoted: mek,
              caption: `🤖 Print do site`,
              })
              console.log(buffer)
break

case 'pint':
 if (!isGrupop) return reply(`🤖 Grupo não encontrado no meu banco de dados\n\n🔰Vip Diamond:\n💵 10R$ Por semana.\n\n🤖 Pagamento via Pix!\n🤖 Este é meu plano caso tenha interesse chame meu dono. wa.me/558181896518.`);
if (userLevell < 2) return reply(`🤖 Você ainda não tem acesso ao meus comandos pq seu nível esta muito baixo`)
reply(mess.wait)
try {
const pint = body.slice(6)
anu = await fetchJson(
         `https://h4ck3rs404-api.herokuapp.com/api/pinterst?q=${pint}&apikey=404Api`,
            { method: "get" }
          );
         
buffer = await getBuffer(anu.data[Math.floor(Math.random() * anu.data.length)])
ft = `${pint}`
client.sendMessage(from, buffer, image, {
              quoted: mek,
              caption: ft,
            })
           reply(mess.success)
            } catch {
            reply("🤖 Opa não encontrei resultado para sua busca")
            }
            
          break
case 'sgith':
        if (!isGrupop) return reply(`🤖 Grupo não encontrado no meu banco de dados\n\n🔰Vip Diamond:\n💵 10R$ Por semana.\n\n🤖 Pagamento via Pix!\n🤖 Este é meu plano caso tenha interesse chame meu dono. wa.me/558181896518.`);
if (userLevell < 2) return reply(`🤖 Você ainda não tem acesso ao meus comandos pq seu nível esta muito baixo`)
if (userLevell < 2) return reply(`🤖 Você ainda não tem acesso ao meus comandos pq seu nível esta muito baixo`)
reply(`🤖 Buscando usuário...`)
try {
const sgith = body.slice(7)
anu = await fetchJson(
         `https://h4ck3rs404-api.herokuapp.com/api/gitstalk?usrnm=${sgith}&apikey=404Api`,
            { method: "get" }
          );
          
buffer = await getBuffer(anu.result.avatar_url)
resultado = `📝Nome: ${anu.result.name}\n
💌BIO: ${anu.result.bio}\n🌍Localização: ${anu.result.location}\n✅Segue: ${anu.result.following}\n📑Seguidores: ${anu.result.followers}\n📢 Repositórios públicos: ${anu.result.public_repos}\n🔰Link: https://github.com/${sgith}`
client.sendMessage(from, buffer, image, {
              quoted: mek,
              caption: resultado,
              })
              } catch {
              reply(mess.error.erro) 
              reply(`🤖 Possível causa do erro: nome de usuário incorreto!`)
              }

break
case 'planos':
reply(mess.wait)
setTimeout(() => {
reply(`\n🔰Vip Diamond:\n💵 10R$ Por semana.\n\n🤖 Pagamento via Pix!\n\n🤖 Este é são meu plano casso tenha interesse chame meu dono. wa.me/558181896518`)
}, 3000)
break
         /* CAMANDOS DAS AULAS */

        case "meu-perfil":
          
          const userLevel = getLevelingLevel(sender);
          const userXp = getLevelingXp(sender); 
          
          const currentLevel = getLevelingLevel(sender); 
          const requiredXp = 5000 * (Math.pow(2, currentLevel) - 1);
          if (userLevel === undefined && userXp === undefined)
            return reply(mess.levelnol);
            
         const nomee = client.contacts[sender].notify || "..."
        num = mek.participants;
        try {
          ppimg = await client.getProfilePicture(
            `${mek.participants.split("@")[0]}@c.us`
          );
        } catch {
          ppimg =
            "https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg";
        }

   teks = `🤖 Seu perfil:\n📝Nome: ${client.contacts[sender].notify}\n🏴Level: ${userLevel}\n🏅Patente: ${patt}[`;      
   nomiie = mek.participant
const ttt = `http://brizas-api.herokuapp.com/photomod/rank?apikey=brizaloka&name=.&atualxp=${userXp}&maxxp=${requiredXp}&desc=2020&colorbar=0061FF&colortext=FF2E00&background=https://i.imgur.com/tVKFNFk.png&profileimg=${ppimg}&rank=${userLevel}/100&level=${userLevel}`
buff = await getBuffer(ttt)

        client.sendMessage(from, buff, image, {
          caption: teks,
          quoted: mek,
        });
        console.log(ttt) 

          break;
          case 'join':
          entra = body.slice(6)
          const response = await mek.acceptInvite (`${entra}`)
    console.log("joined to: " + response.jidd)
          break
case 'rankgay':
addFilter(from)  
if(!isGroup) return reply(mess.only.group)
try{
d = []
ret = '🏳️‍🌈 Rank dos mais gays\n'
for(i = 0; i < 5; i++) {
r = Math.floor(Math.random() * groupMetadata.participants.length + 0)
ret += `🏳️‍🌈❧ @${groupMembers[r].jid.split('@')[0]}\n`
d.push(groupMembers[r].jid)
}
mentions(ret, d, true)
} catch (e) {
console.log(e)
reply('Deu erro, tente novamente :/')
}
break
case 'rankgostosas':
addFilter(from)  
if (!isGroup) return reply(mess.only.group)
member = []
const p1 = groupMembers
const p2 = groupMembers
const p3 = groupMembers
const p4 = groupMembers
const p5 = groupMembers
const o1 = p1[Math.floor(Math.random() * p1.length)]
const o2 = p2[Math.floor(Math.random() * p2.length)]
const o3 = p3[Math.floor(Math.random() * p3.length)]
const o4 = p4[Math.floor(Math.random() * p4.length)]
const o5 = p5[Math.floor(Math.random() * p5.length)]
luy = `
Paradas!🤚🤚\n\n1=🤚🤭@${o1.jid.split('@')[0]}🤚🤭\n\n\n2=🤚🤭@${o2.jid.split('@')[0]}🤚🤭\n\n\n3=🤚🤭@${o3.jid.split('@')[0]}🤚🤭\n\n\n4=🤚🤭@${o4.jid.split('@')[0]}🤚🤭\n\n\n5=🤚🤭@${o5.jid.split('@')[0]}🤚🤭\n\n\nMultas por serem gostosas dms😳 pague pena enviando nud no PV do dono😊 by Bot`
member.push(o1.jid)
member.push(o2.jid)
member.push(o3.jid)
member.push(o4.jid)
member.push(o5.jid)
mentions(luy, member, true)
break
case  'casal':
if (!isGroup) return reply(mess.only.group)
membr = []
const suamae11 = groupMembers
const suamae21 = groupMembers
const teupai11 = suamae11[Math.floor(Math.random() * suamae11.length)]
const teupai21 = suamae21[Math.floor(Math.random() * suamae21.length)]
var shipted1 = ["1%", `2%`, `3%`, `4%`, `5%`, `6%`, `7`, `8%`, `9%`, `10`, `11%`, `12%`,`13%`, `14%`, `15%`, `16%`, `17%`, `18%`, `19%`, `20%`, `21%`, `22`, `23%`, `24%`, `25%`, `26%`, `27%`, `28%`, `27%`, `28%`, `29%`, `30%`, `31%`, `32%`, `33%`, `34%`, `35%`, `36%`, `37%`, `38%`, `39%`, `40%`, `41%`, `42%`, `43%`, `44%`, `45%`, `46%`, `47%`, `48%`, `49%`, `50%`, `51%`, `52%`, `53%`, `54%`, `55%`, `56%`, `57%`, `58%`, `59%`, `60%`, `61%`, `62%`, `63%`, `64%`, `65%`, `66%`, `67%`, `68%`, `69%`, `70%`, `71%`, `72%`, `73%`, `74%`, `75%`, `76%`, `77%`, `78%`, `79%`, `80%`, `81%`, `82%`, `85%`, `84%`, `85%`, `86%`, `87%`, `88%`, `89%`, `90%`, `91%`, `92%`, `93%`, `94%`, `95%`, `96%`, `97%`, `98%`, `99%`, `100%`]
const shipted = shipted1[Math.floor(Math.random() * shipted1.length)]
jet = `🤖 Vou shipar esses dois:\n\nEsse:@${teupai11.jid.split('@')[0]}\ncom esse:@${teupai21.jid.split('@')[0]}\ncom uma porcentagem de: ${shipted}`
membr.push(teupai11.jid)
membr.push(teupai21.jid)
mentions(jet, membr, true)
break
case 'rankcornos':
addFilter(from)  
if (!isGroup) return reply(`Esse comando so pode ser usado em grupos parsa`)
membr = []
const corno1 = groupMembers
const corno2 = groupMembers
const corno3 = groupMembers
const corno4 = groupMembers
const corno5 = groupMembers
const cornos1 = corno1[Math.floor(Math.random() * corno1.length)]
const cornos2 = corno2[Math.floor(Math.random() * corno2.length)]
const cornos3 = corno3[Math.floor(Math.random() * corno3.length)]
const cornos4 = corno4[Math.floor(Math.random() * corno4.length)]
const cornos5 = corno5[Math.floor(Math.random() * corno5.length)]
var porcentagemcorno = ["1%", `2%`, `3%`, `4%`, `5%`, `6%`, `7`, `8%`, `9%`, `10`, `11%`, `12%`,`13%`, `14%`, `15%`, `16%`, `17%`, `18%`, `19%`, `20%`, `21%`, `22`, `23%`, `24%`, `25%`, `26%`, `27%`, `28%`, `27%`, `28%`, `29%`, `30%`, `31%`, `32%`, `33%`, `34%`, `35%`, `36%`, `37%`, `38%`, `39%`, `40%`, `41%`, `42%`, `43%`, `44%`, `45%`, `46%`, `47%`, `48%`, `49%`, `50%`, `51%`, `52%`, `53%`, `54%`, `55%`, `56%`, `57%`, `58%`, `59%`, `60%`, `61%`, `62%`, `63%`, `64%`, `65%`, `66%`, `67%`, `68%`, `69%`, `70%`, `71%`, `72%`, `73%`, `74%`, `75%`, `76%`, `77%`, `78%`, `79%`, `80%`, `81%`, `82%`, `85%`, `84%`, `85%`, `86%`, `87%`, `88%`, `89%`, `90%`, `91%`, `92%`, `93%`, `94%`, `95%`, `96%`, `97%`, `98%`, `99%`, `O chifre desse ai bate na lua ksksksk`]
const porcentagemc = porcentagemcorno[Math.floor(Math.random() * porcentagemcorno.length)]
ytb = `
Esses são os cornos do grupo ${groupName}\n@${cornos1.jid.split('@')[0]}\nCom uma porcentagem de ${porcentagemc}\n@${cornos2.jid.split('@')[0]}\nCom uma porcentagem de ${porcentagemc}\n@${cornos3.jid.split('@')[0]}\nCom uma porcentagem de ${porcentagemc}\n@${cornos4.jid.split('@')[0]}\nCom uma porcentagem de ${porcentagemc}\n@${cornos5.jid.split('@')[0]}\nCom uma porcentagem de ${porcentagemc}\n\n⚡ ${setting.NamaBot} ⚡`
membr.push(cornos1.jid)
membr.push(cornos2.jid)
membr.push(cornos3.jid)
membr.push(cornos4.jid)
membr.push(cornos5.jid)
mentions(ytb, membr, true)
break
case 'rankotakus':
addFilter(from)  
if (!isGroup) return reply(`Comando so pode ser utiizado em grupos parsa`)
membr = []
const otaku1 = groupMembers
const otaku2 = groupMembers
const otaku3 = groupMembers
const otaku4 = groupMembers
const otaku5 = groupMembers
const otaku6 = groupMembers
const otaku7 = groupMembers
const otaku8 = groupMembers
const otaku9 = groupMembers
const otaku10 = groupMembers
const otakus1 = otaku1[Math.floor(Math.random() * otaku1.length)]
const otakus2 = otaku2[Math.floor(Math.random() * otaku2.length)]
const otakus3 = otaku3[Math.floor(Math.random() * otaku3.length)]
const otakus4 = otaku4[Math.floor(Math.random() * otaku4.length)]
const otakus5 = otaku5[Math.floor(Math.random() * otaku5.length)]
const otakus6 = otaku6[Math.floor(Math.random() * otaku6.length)]
const otakus7 = otaku7[Math.floor(Math.random() * otaku7.length)]
const otakus8 = otaku8[Math.floor(Math.random() * otaku8.length)]
const otakus9 = otaku9[Math.floor(Math.random() * otaku9.length)]
const otakus10 = otaku10[Math.floor(Math.random() * otaku10.length)]
ytb = `esses são os otakus fedidos do grupo\n@${otakus1.jid.split('@')[0]}\n@${otakus2.jid.split('@')[0]}\n@${otakus3.jid.split('@')[0]}\n@${otakus4.jid.split('@')[0]}\n@${otakus5.jid.split('@')[0]}\n@${otakus6.jid.split('@')[0]}\n@${otakus7.jid.split('@')[0]}\n@${otakus8.jid.split('@')[0]}\n@${otakus9.jid.split('@')[0]}\n@${otakus10.jid.split('@')[0]}\n\n⚡ ${setting.NamaBot} ⚡`
membr.push(otakus1.jid)
membr.push(otakus2.jid)
membr.push(otakus3.jid)
membr.push(otakus4.jid)
membr.push(otakus5.jid)
membr.push(otakus6.jid)
membr.push(otakus7.jid)
membr.push(otakus8.jid)
membr.push(otakus9.jid)
membr.push(otakus10.jid)
mentions(ytb, membr, true)
break
case 'rankpau':
addFilter(from)  
if (!isGroup) return reply(mess.only.group)
membr = []
const pauz1 = groupMembers
const pauz2 = groupMembers
const pauz3 = groupMembers
const pauz4 = groupMembers
const pauz5 = groupMembers
const paus1 = pauz1[Math.floor(Math.random() * pauz1.length)]
const paus2 = pauz2[Math.floor(Math.random() * pauz2.length)]
const paus3 = pauz3[Math.floor(Math.random() * pauz3.length)]
const paus4 = pauz4[Math.floor(Math.random() * pauz4.length)]
const paus5 = pauz5[Math.floor(Math.random() * pauz5.length)]
var pcpau1 = ["Minuscúlo", `Pequenino`, `Pequeno`, `Médio`, `Grandinho`, `Grande`, `Grandão`, `Gigante`, `Gigantesco`, `Enorme`, `BATENDO NA LUA`, `QUEIMADO, TÃO GRANDE QUE BATEU NO SOL E QUEIMOU ksksksk`]
var pcpau2 = ["Minuscúlo", `Pequenino`, `Pequeno`, `Médio`, `Grandinho`, `Grande`, `Grandão`, `Gigante`, `Gigantesco`, `Enorme`, `BATENDO NA LUA`, `QUEIMADO, TÃO GRANDE QUE BATEU NO SOL E QUEIMOU ksksksk`]
var pcpau3 = ["Minuscúlo", `Pequenino`, `Pequeno`, `Médio`, `Grandinho`, `Grande`, `Grandão`, `Gigante`, `Gigantesco`, `Enorme`, `BATENDO NA LUA`, `QUEIMADO, TÃO GRANDE QUE BATEU NO SOL E QUEIMOU ksksksk`]
var pcpau4 = ["Minuscúlo", `Pequenino`, `Pequeno`, `Médio`, `Grandinho`, `Grande`, `Grandão`, `Gigante`, `Gigantesco`, `Enorme`, `BATENDO NA LUA`, `QUEIMADO, TÃO GRANDE QUE BATEU NO SOL E QUEIMOU ksksksk`]
var pcpau5 = ["Minuscúlo", `Pequenino`, `Pequeno`, `Médio`, `Grandinho`, `Grande`, `Grandão`, `Gigante`, `Gigantesco`, `Enorme`, `BATENDO NA LUA`, `QUEIMADO, TÃO GRANDE QUE BATEU NO SOL E QUEIMOU ksksksk`]
const pc1 = pcpau1[Math.floor(Math.random() * pcpau1.length)]
const pc2 = pcpau2[Math.floor(Math.random() * pcpau2.length)]
const pc3 = pcpau3[Math.floor(Math.random() * pcpau3.length)]
const pc4 = pcpau4[Math.floor(Math.random() * pcpau4.length)]
const pc5 = pcpau5[Math.floor(Math.random() * pcpau5.length)]
pdr = `Esses são os caras com o menor e maior pau do Grupo\n${groupName}\n\n@${paus1.jid.split('@')[0]}\n${pc1}\n@${paus2.jid.split('@')[0]}\n${pc2}\n@${paus3.jid.split('@')[0]}\n${pc3}\n@${paus4.jid.split('@')[0]}\n${pc4}\n@${paus5.jid.split('@')[0]}\n${pc5}\n\n ${setting.NamaBot}`
membr.push(paus1.jid)
membr.push(paus2.jid)
membr.push(paus3.jid)
membr.push(paus4.jid)
membr.push(paus5.jid)
mentions(pdr, membr, true)
break 
case 'block':
addFilter(from)  
if (!isGroup) return reply(mess.only.group)
if (!isOwner) return  reply(mess.only.ownerB)
if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return 
mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
pru = '.\n'
for (let _ of mentioned) {
pru += `@${_.split('@')[0]}\n`
}
ban.push(`${mentioned}`)
fs.writeFileSync('./database/json/banned.json', JSON.stringify(ban))
susp = `🚫@${mentioned[0].split('@')[0]} foi banido e não poderá mais usar os comandos do bot🚫`
mentions(`${susp}`, mentioned, true)   
break
case 'unblock':
addFilter(from)  
if (!isGroup) return reply(mess.only.group)
if (!isOwner) return  reply(mess.only.ownerB)
if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return 
mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
pru = '.\n'
for (let _ of mentioned) {
pru += `@${_.split('@')[0]}\n`
}
ban.splice(`${mentioned}`)
fs.writeFileSync('./database/json/banned.json', JSON.stringify(ban))
susp = `❎@${mentioned[0].split('@')[0]} foi desbanido e poderá novamente usar os comandos do bot❎`
mentions(`${susp}`, mentioned, true)   
break
case 'fecharr':
fcc = body.slice(9)
strr = moment.tz("America/Sao_Paulo").format('HH:mm:ss')
if (strr === `${fcc}`){
client.groupSettingChange(from, GroupSettingChange.messageSend, true)
}
break
        case 'help':
        case 'menu':
        case "ajuda":
        
        if (!isGrupop) return reply(`🤖 Grupo não encontrado no meu banco de dados\n\n🔰Vip Diamond:\n💵 10R$ Por semana.\n\n🤖 Pagamento via Pix!\n🤖 Este é meu plano caso tenha interesse chame meu dono. wa.me/558181896518.`);
        if (userLevell < 2) return reply(`🤖 Você ainda não tem acesso ao meus comandos pq seu nível esta muito baixo`)
        if (groupMetadata.subjectTime < 1500) return reply(`espere um pouco`)
        reply(`🤖\n◤•Saudações•◢
           
 | ✑ Olá ${client.contacts[sender].notify}  
 | ✑ Seja bem vindo(a)
 | ✑ Prefixo:『 ${prefix} 』
            
         ◤•Seu perfil•◢  
            
 | ✑ Level : ${getLevelingLevel(sender)}
 | ✑ Patente : ${patt}
 | ✑${prefix}Meu-Perfil

×××××××××××××××××××××××××××××××
                 
╭──────────────────╮
 |    >Modificação e criação<
 |   ╭━━━━━━━━━━━━━━━╮                
 |    ◤•Modificar WhatsApp•◢
 |   ╰━━━━━━━━━━━━━━━╯
 |
 | ✑${prefix}Modders
 |
 |         ╭━━━━━━━━━╮
 |          ◤•Sketchware•◢
 |         ╰━━━━━━━━━╯
 |
 | ✑${prefix}Sket
╰──────────────────╯

×××××××××××××××××××××××××××××××
  
╭──────────────────╮        
 |      CMDS BÁSICOS
 |
 | ✑${prefix}play 
 | ✑${prefix}toimg
 | ✑${prefix}figu
 | ✑${prefix}f
 | ✑${prefix}txtf
 | ✑${prefix}wame
 | ✑${prefix}toimg 
 | ✑${prefix}memes 
╰──────────────────╯

×××××××××××××××××××××××××××××××

╭──────────────────╮                 
 |      PESQUISAS/BAIXAR
 |
 | ✑${prefix}mercado-livre
 | ✑${prefix}pesquisa
 | ✑${prefix}pint
 | ✑${prefix}ig
 | ✑${prefix}memes
 | ✑${prefix}play
╰──────────────────╯

×××××××××××××××××××××××××××××××
                 
╭──────────────────╮              
 |         BRINCADEIRAS
 |
 | ✑${prefix}gostoso
 | ✑${prefix}gostosa
 | ✑${prefix}gay
 | ✑${prefix}casal 
 | ✑${prefix}corno
 | ✑${prefix}gado
 | ✑${prefix}nazista
 | ✑${prefix}amgolpe 
 | ✑${prefix}tapa 
 | ✑${prefix}chute 
 |
 |  RANKS DAS BRINCADEiRAS
 |
 | ✑${prefix}rankgay [off
 | ✑${prefix}rankpau [off]
 | ✑${prefix}rankotakus [off]
 | ✑${prefix}rankgays [off]
 | ✑${prefix}rankgostosas [off]
 | ✑${prefix}rankcornos [off]
 | ✑${prefix}ranknazista [off]
╰──────────────────╯

×××××××××××××××××××××××××××××××
                              
┏━━━━━━━━━━━━━━━━┓
┃         >INFO DONO        
┃            AJUDANTE<     
┃┈┈┈┈┈┈┈┈┈┈┈┈┈┈          
┃ ✑ Nome: Adrx (Dono)
┃ ✑ Nmr: wa.me/8181896518 
┃┈┈┈┈┈┈┈┈┈┈┈┈┈┈
┃ ✑ Nome: Vinix (Ajudante)
┃ ✑ Nmr: N qro ser travadu
┗━━━━━━━━━━━━━━━━┛

━━━━❮Splash Bot❯━━━━`)

          break;
          case 'fastvid':
if (!isQuotedVideo) return reply('Marque um vídeo')
reply(mess.wait)
encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
media = await client.downloadAndSaveMediaMessage(encmedia)
ran = getRandom('.mp4')
exec(`ffmpeg -i ${media} -filter_complex "[0:v]setpts=0.5*PTS[v];[0:a]atempo=2[a]" -map "[v]" -map "[a]" ${ran}`, (err) => {
fs.unlinkSync(media)
if (err) return reply(`Err: ${err}`)
buffer453 = fs.readFileSync(ran)
client.sendMessage(from, buffer453, video, { mimetype: 'video/mp4', quoted: mek })
fs.unlinkSync(ran)
})		
break
case 'bass3':
addFilter(from)  
msgFilter.isFiltered(from)
if (!isQuotedAudio) return reply('Marque um áudio')
reply(mess.wait)
ass = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
bas = await client.downloadAndSaveMediaMessage(ass)
ran = getRandom('.mp3')
exec(`ffmpeg -i ${bas} -af equalizer=f=20:width_type=o:width=2:g=15 ${ran}`, (err, stderr, stdout) => {
fs.unlinkSync(bas)
if (err) return reply('Error!')
hah = fs.readFileSync(ran)
client.sendMessage(from, hah, audio, {mimetype: 'audio/mp4', ptt:true, quoted: mek})
fs.unlinkSync(ran)
})
break
case 'bass':  
  if (!isQuotedAudio) return reply('Marque um áudio')
  reply(mess.wait)
if (isBanned) return reply(mess.only.benned)
msgFilter.isFiltered(from)
ass = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
bas = await client.downloadAndSaveMediaMessage(ass)
ran = getRandom('.mp3')
exec(`ffmpeg -i ${bas} -af equalizer=f=20:width_type=o:width=2:g=15 ${ran}`, (err, stderr, stdout) => {
fs.unlinkSync(bas)
if (err) return reply('Error!')
hah = fs.readFileSync(ran)
client.sendMessage(from, hah, audio, {mimetype: 'audio/mp4', ptt:true, quoted: mek})
fs.unlinkSync(ran)
})
break
case 'bass2': 
  if (!isQuotedAudio) return reply('Marque um áudio')
  reply(mess.wait)
if (isBanned) return reply(mess.only.benned)
encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
media = await client.downloadAndSaveMediaMessage(encmedia)
ran = getRandom('.mp3')
exec(`ffmpeg -i ${media} -af equalizer=f=94:width_type=o:width=2:g=30 ${ran}`, (err, stderr, stdout) => {
fs.unlinkSync(media)
if (err) return reply('Error!')
hah = fs.readFileSync(ran)
client.sendMessage(from, hah, audio, {mimetype: 'audio/mp4', ptt:true, quoted: mek})
fs.unlinkSync(ran)
})
break
case 'estourar': 
msgFilter.isFiltered(from)
if (!isQuotedAudio) return reply('Marque um áudio')
reply(mess.wait)
ass = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
bas = await client.downloadAndSaveMediaMessage(ass)
ran = getRandom('.mp3')
exec(`ffmpeg -i ${bas} -af equalizer=f=90:width_type=o:width=2:g=30 ${ran}`, (err, stderr, stdout) => {
fs.unlinkSync(bas)
if (err) return reply('Error!')
hah = fs.readFileSync(ran)
client.sendMessage(from, hah, audio, {mimetype: 'audio/mp4', ptt:true, quoted: mek})
fs.unlinkSync(ran)
})
break
case 'fast':
if (!isQuotedAudio) return reply('Marque um áudio')
reply(mess.wait)
encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
media = await client.downloadAndSaveMediaMessage(encmedia)
ran = getRandom('.mp3')
exec(`ffmpeg -i ${media} -filter:a "atempo=0.9,asetrate=95100" ${ran}`, (err, stderr, stdout) => {
fs.unlinkSync(media)
if (err) return reply('Erro')
hah = fs.readFileSync(ran)
client.sendMessage(from, hah, audio, {mimetype: 'audio/mp4', ptt:true, quoted: mek})
fs.unlinkSync(ran)
})
break
case 'esquilo':
msgFilter.isFiltered(from)
if (!isQuotedAudio) return reply('Marque um áudio')
reply(mess.wait)
pai = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
tup = await client.downloadAndSaveMediaMessage(pai)
ran = getRandom('.mp3')
exec(`ffmpeg -i ${tup} -filter:a "atempo=0.7,asetrate=65100" ${ran}`, (err, stderr, stdout) => {
fs.unlinkSync(tup)
if (err) return reply('Error!')
hah = fs.readFileSync(ran)
client.sendMessage(from, hah, audio, {mimetype: 'audio/mp4', ptt:true, quoted: mek})
fs.unlinkSync(ran)
})
break
        case "listademar":
          client.updatePresence(from, Presence.composing);
          if (!isGrupop) return reply(mess.only.daftarB);
          if (!isGroup) return reply(mess.only.group);
          teks = `Lista admin do grupo*${groupMetadata.subject}*\nTotal : ${groupAdmins.length}\n\n`;
          no = 0;
          for (let admon of groupAdmins) {
            no += 1;
            teks += `[${no.toString()}] @${admon.split("@")[0]}\n`;
          }
          mentions(teks, groupAdmins, true);
          break;
         
case 'cep':
if (args < 1) return reply(`🤖 Digite um cep! ex "/cep 55530000"`) 
if (args.length > 8) return reply(`🤖 Digite um cep valido`) 
cepi = body.slice(5)
reply(`🤖 Aguarde um momento...`)
try {
ddC = `https://viacep.com.br/ws/${cepi}/json/`
resultadoC = `🤖\nCEP: ${ddC.cep}\nLOGRADOURO: ${ddC.logradouro}\nCONPLEMENTO: ${ddC.complemento}\nBAIRRO: ${ddC.bairro}\nLOCALIDADE: ${ddC.localidade}\nUF: ${ddC.uf}\nIBGE: ${ddC.ibge}\nDDD: ${ddC.ddd}`
reply(resultadoC)
} catch {
reply(`🤖 Cep não encontrado`)
}
break


case 'entre':
if (!isOwner) return reply(`🤖 Vc n tem permissão para este tipo de comandos`)
if (args < 1) return reply(`🤖 Kade a id do gp`)
try {
limpa = body.slice(7)
const codeInvite = `${limpa}`;
const responsee = await client.acceptInvite(codeInvite);
reply(`🤖 Entrei no grupo man`)
} catch {
reply(`🤖 Não foi possível entra neste grupo`)

}
break
case 'gsenha':
await senhas()
reply(`${dds}`)
break
case 'gpessoa':
dadss = await fetchJson(
         `http://brizas-api.herokuapp.com/gerador/pessoa?apikey=brizaloka`,
            { method: "get" }
          );
if (dadss.status === 200){
await gpessoa()
reply(`${dds}`)
} else {
reply(`🤖 Umm Desculpe, minhas requests acabaram, espere até meu dono renovar o plano da API dele.`)
}
break
case 'gcpf':
await gcpf()
reply(`${dds}`)
break
case 'modders':
await menum()
reply(`${dds}`)
break
case 'gdocc':
await gdcc()
reply(`${dds}`)
break
        case "fechargp":  
      if (!isGrupop) return reply(`🤖 Grupo não encontrado no meu banco de dados\n\n🔰Vip Diamond:\n💵 10R$ Por semana.\n\n🤖 Pagamento via Pix!\n🤖 Este é meu plano caso tenha interesse chame meu dono. wa.me/558181896518.`);
        
        if (userLevell < 2) return reply(`🤖 Você ainda não tem acesso ao meus comandos pq seu nível esta muito baixo`)
          client.updatePresence(from, Presence.composing);
          if (!isGroup) return reply(mess.only.group);
          if (!isGroupAdmins) return reply(mess.only.admin);
          if (!isBotGroupAdmins) return reply(mess.only.Badmin);
          var nomor = mek.participant;
          const close = {
            text: `Grupo fechado pelo administrador @${
              nomor.split("@s.whatsapp.net")[0]
            }\nagora *apenas administradores* podem enviar mensagens`,
            contextInfo: { mentionedJid: [nomor] },
          };
          client.groupSettingChange(from, GroupSettingChange.messageSend, true);
          reply(close);
          break;
        case "abrirgp":
                if (!isGrupop) return reply(`🤖 Grupo não encontrado no meu banco de dados\n\n🔰Vip Diamond:\n💵 10R$ Por semana.\n\n🤖 Pagamento via Pix!\n🤖 Este é meu plano caso tenha interesse chame meu dono. wa.me/558181896518.`);
        
        if (userLevell < 2) return reply(`🤖 Você ainda não tem acesso ao meus comandos pq seu nível esta muito baixo`)
          client.updatePresence(from, Presence.composing);
          if (!isGroup) return reply(mess.only.group);
          if (!isGroupAdmins) return reply(mess.only.admin);
          if (!isBotGroupAdmins) return reply(mess.only.Badmin);
          open = {
            text: `Grupo aberto pelo administrador @${
              sender.split("@")[0]
            }\nagora *todos os participantes* podem enviar mensagens`,
            contextInfo: { mentionedJid: [sender] },
          };
          client.groupSettingChange(
            from,
            GroupSettingChange.messageSend,
            false
          );
          client.sendMessage(from, open, text, { quoted: mek });
          break;
        
        case "figu":
        case "fig":
        case "f":
       
       if (!isGrupop) return reply(`🤖 Grupo não encontrado no meu banco de dados\n\n🔰Vip Diamond:\n💵 10R$ Por semana.\n\n🤖 Pagamento via Pix!\n🤖 Este é meu plano caso tenha interesse chame meu dono. wa.me/558181896518.`);
        
        if (userLevell < 2) return reply(`🤖 Você ainda não tem acesso ao meus comandos pq seu nível esta muito baixo`)
          if (
            ((isMedia && !mek.message.videoMessage) || isQuotedImage) &&
            args.length == 0
          ) {
            const encmedia = isQuotedImage
              ? JSON.parse(JSON.stringify(mek).replace("quotedM", "m")).message
                  .extendedTextMessage.contextInfo
              : mek;
            const media = await client.downloadAndSaveMediaMessage(encmedia);
            ran = getRandom(".webp");
            await ffmpeg(`./${media}`)
              .input(media)
              .on("start", function (cmd) {
                console.log(`Started : ${cmd}`);
              })
              .on("error", function (err) {
                console.log(`Error : ${err}`);
                fs.unlinkSync(media);
                reply(mess.error.stick);
              })
              .on("end", function () {
                console.log("Finish");
                client.sendMessage(from, fs.readFileSync(ran), sticker, {
                  quoted: mek,
                });
                fs.unlinkSync(media);
                fs.unlinkSync(ran);
              })
              .addOutputOptions([
                `-vcodec`,
                `libwebp`,
                `-vf`,
                `scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`,
              ])
              .toFormat("webp")
              .save(ran);
          } else if (
            ((isMedia && mek.message.videoMessage.seconds < 11) ||
              (isQuotedVideo &&
                mek.message.extendedTextMessage.contextInfo.quotedMessage
                  .videoMessage.seconds < 11)) &&
            args.length == 0
          ) {
            const encmedia = isQuotedVideo
              ? JSON.parse(JSON.stringify(mek).replace("quotedM", "m")).message
                  .extendedTextMessage.contextInfo
              : mek;
            const media = await client.downloadAndSaveMediaMessage(encmedia);
            ran = getRandom(".webp");
            reply(mess.wait);
            await ffmpeg(`./${media}`)
              .inputFormat(media.split(".")[1])
              .on("start", function (cmd) {
                console.log(`Started : ${cmd}`);
              })
              .on("error", function (err) {
                console.log(`Error : ${err}`);
                fs.unlinkSync(media);
                tipe = media.endsWith(".mp4") ? "video" : "gif";
                reply(
                  `❌ Falhou, no momento da conversão ${tipe} para o adesivo`
                );
              })
              .on("end", function () {
                console.log("Finish");
                client.sendMessage(from, fs.readFileSync(ran), sticker, {
                  quoted: mek,
                });
                fs.unlinkSync(media);
                fs.unlinkSync(ran);
              })
              .addOutputOptions([
                `-vcodec`,
                `libwebp`,
                `-vf`,
                `scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`,
              ])
              .toFormat("webp")
              .save(ran);
          } else if ((isMedia || isQuotedImage) && args[0] == "nobg") {
            const encmedia = isQuotedImage
              ? JSON.parse(JSON.stringify(mek).replace("quotedM", "m")).message
                  .extendedTextMessage.contextInfo
              : mek;
            const media = await client.downloadAndSaveMediaMessage(encmedia);
            ranw = getRandom(".webp");
            ranp = getRandom(".png");
            reply(mess.wait);
            keyrmbg = "Your-ApiKey";
            await removeBackgroundFromImageFile({
              path: media,
              apiKey: keyrmbg.result,
              size: "auto",
              type: "auto",
              ranp,
            }).then((res) => {
              fs.unlinkSync(media);
              let buffer = Buffer.from(res.base64img, "base64");
              fs.writeFileSync(ranp, buffer, (err) => {
                if (err)
                  return reply(
                    "Falha, ocorreu um erro, tente novamente mais tarde."
                  );
              });
              exec(
                `ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${ranw}`,
                (err) => {
                  fs.unlinkSync(ranp);
                  if (err) return reply(mess.error.stick);
                  client.sendMessage(from, fs.readFileSync(ranw), sticker, {
                    quoted: mek,
                  });
                }
              );
            });
            /*} else if ((isMedia || isQuotedImage) && colors.includes(args[0])) {
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const media = await client.downloadAndSaveMediaMessage(encmedia)
						ran = getRandom('.webp')
						await ffmpeg(`./${media}`)
							.on('start', function (cmd) {
								console.log('Started :', cmd)
							})
							.on('error', function (err) {
								fs.unlinkSync(media)
								console.log('Error :', err)
							})
							.on('end', function () {
								console.log('Finish')
								fs.unlinkSync(media)
								client.sendMessage(from, fs.readFileSync(ran), sticker, {quoted: mek})
								fs.unlinkSync(ran)
							})
							.addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=${args[0]}@0.0, split [a][b]; [a] palettegen=reserve_transparent=off; [b][p] paletteuse`])
							.toFormat('webp')
							.save(ran)*/
          } else {
            reply(
              `Envie fotos com legendas *.f* ou marque uma imagem que já foi enviada`
            );
          }
          break;
        case "setprefix":
          if (args.length < 1) return;
          if (!isOwner) return reply(mess.only.ownerB);
          prefix = args[0];
          reply(`🤖 Prefixo alterado para: ${prefix}`);
          break;
        case "txtf":
                if (!isGrupop) return reply(`🤖 Grupo não encontrado no meu banco de dados\n\n🔰Vip Diamond:\n💵 10R$ Por semana.\n\n🤖 Pagamento via Pix!\n🤖 Este é meu plano caso tenha interesse chame meu dono. wa.me/558181896518.`);
        
        if (userLevell < 2) return reply(`🤖 Você ainda não tem acesso ao meus comandos pq seu nível esta muito baixo`)
          if (args.length < 0) return reply("🤖 Opa digite um texto para eu fazer o seu sticker!");
          var txt = encodeURI(body.slice(5));
          anu = await getBuffer(`https://api.xteam.xyz/attp?file&text=${txt}`);
          client.sendMessage(from, anu, sticker, { quoted: mek });
          break;
        case "marcartodos":
        if (!isGrupop) return reply(`🤖 Grupo não encontrado no meu banco de dados\n\n🔰Vip Diamond:\n💵 10R$ Por semana.\n\n🤖 Pagamento via Pix!\n🤖 Este é meu plano caso tenha interesse chame meu dono. wa.me/558181896518.`);
        
        if (userLevell < 2) return reply(`🤖 Você ainda não tem acesso ao meus comandos pq seu nível esta muito baixo`)
          if (!isGroup) return reply(mess.only.group);
          if (!isGroupAdmins) return reply(mess.only.admin);
          members_id = [];
          teks = args.length > 1 ? body.slice(8).trim() : "";
          teks += "\n\n";
          for (let mem of groupMembers) {
            teks += `*#* @${mem.jid.split("@")[0]}\n`;
            members_id.push(mem.jid);
          }
          mentions(teks, members_id, true);
          break;
        case "marcartodos2":
                if (!isGrupop) return reply(`🤖 Grupo não encontrado no meu banco de dados\n\n🔰Vip Diamond:\n💵 10R$ Por semana.\n\n🤖 Pagamento via Pix!\n🤖 Este é meu plano caso tenha interesse chame meu dono. wa.me/558181896518.`);
        
        if (userLevell < 2) return reply(`🤖 Você ainda não tem acesso ao meus comandos pq seu nível esta muito baixo`)

          members_id = [];
          teks = args.length > 1 ? body.slice(8).trim() : "";
          teks += "\n\n";
          for (let mem of groupMembers) {
            teks += `╠➥ @${mem.jid.split("@")[0]}\n`;
            members_id.push(mem.jid);
          }
          reply(teks);
          reply(`TOTAIS DE MEMBROS : ${groupMembers.length}`);
          break;
        case "marcartodos3":
        if (!isGrupop) return reply(`🤖 Grupo não encontrado no meu banco de dados\n\n🔰Vip Diamond:\n💵 10R$ Por semana.\n\n🤖 Pagamento via Pix!\n🤖 Este é meu plano caso tenha interesse chame meu dono. wa.me/558181896518.`);
        
        if (userLevell < 2) return reply(`🤖 Você ainda não tem acesso ao meus comandos pq seu nível esta muito baixo`)
          members_id = [];
          teks = args.length > 1 ? body.slice(8).trim() : "";
          teks += "\n\n";
          for (let mem of groupMembers) {
            teks += `╠➥ https://wa.me/${mem.jid.split("@")[0]}\n`;
            members_id.push(mem.jid);
          }
          client.sendMessage(from, teks, text, {
            detectLinks: false,
            quoted: mek,
          });
          break;
        case "grave1":
                if (!isGrupop) return reply(`🤖 Grupo não encontrado no meu banco de dados\n\n🔰Vip Diamond:\n💵 10R$ Por semana.\n\n🤖 Pagamento via Pix!\n🤖 Este é meu plano caso tenha interesse chame meu dono. wa.me/558181896518.`);
        
        if (userLevell < 2) return reply(`🤖 Você ainda não tem acesso ao meus comandos pq seu nível esta muito baixo`)
          reply(mess.wait);

          encmedia = JSON.parse(JSON.stringify(mek).replace("quotedM", "m"))
            .message.extendedTextMessage.contextInfo;
          media = await client.downloadAndSaveMediaMessage(encmedia);
          ran = getRandom(".mp3");
          exec(
            `ffmpeg -i ${media} -af equalizer=f=94:width_type=o:width=2:g=19 ${ran}`,
            (err, stderr, stdout) => {
              fs.unlinkSync(media);
              if (err) return reply("Error!");
              hah = fs.readFileSync(ran);
              client.sendMessage(from, hah, audio, {
                mimetype: "audio/mp4",
                ptt: true,
                quoted: mek,
              });
              fs.unlinkSync(ran);
            }
          );
          break;
        case "grave2":
                if (!isGrupop) return reply(`🤖 Grupo não encontrado no meu banco de dados\n\n🔰Vip Diamond:\n💵 10R$ Por semana.\n\n🤖 Pagamento via Pix!\n🤖 Este é meu plano caso tenha interesse chame meu dono. wa.me/558181896518.`);
        
        if (userLevell < 2) return reply(`🤖 Você ainda não tem acesso ao meus comandos pq seu nível esta muito baixo`)
          reply(mess.wait);
          encmedia = JSON.parse(JSON.stringify(mek).replace("quotedM", "m"))
            .message.extendedTextMessage.contextInfo;
          media = await client.downloadAndSaveMediaMessage(encmedia);
          ran = getRandom(".mp3");
          exec(
            `ffmpeg -i ${media} -af equalizer=f=94:width_type=o:width=2:g=29 ${ran}`,
            (err, stderr, stdout) => {
              fs.unlinkSync(media);
              if (err) return reply("Error!");
              hah = fs.readFileSync(ran);
              client.sendMessage(from, hah, audio, {
                mimetype: "audio/mp4",
                ptt: true,
                quoted: mek,
              });
              fs.unlinkSync(ran);
            }
          );
          break;

        case "mudarfoto":
        if (!isOwner){
        reply(mess.only.ownerB)
        } return
          reply("🤖 Opa ja to mudando");
          client.updatePresence(from, Presence.composing);
          if (!isQuotedImage)
            return reply(
              `Envie fotos com legendas ${prefix}setbotpp ou tags de imagem que já foram enviadas`
            );
          if (!isOwner) return reply(mess.only.ownerB);
          enmedia = JSON.parse(JSON.stringify(mek).replace("quotedM", "m"))
            .message.extendedTextMessage.contextInfo;
          media = await client.downloadAndSaveMediaMessage(enmedia);
          await client.updateProfilePicture(botNumber, media);
          reply("Obrigado pelo novo perfil😗");
          break;
        case "setdesc":
          if (!isGroup) return reply(mess.only.group);
          if (!isGroupAdmins) return reply(mess.only.admin);
          if (!isBotGroupAdmins) return reply(mess.only.Badmin);
          client.groupUpdateDescription(from, `${body.slice(9)}`);
          client.sendMessage(from, "🤖 Descrição alterda com sucesso!", text, {
            quoted: mek,
          });
          break;

        case "promover":
        if (!isGrupop) return reply(`🤖 Grupo não encontrado no meu banco de dados\n\n🔰Vip Diamond:\n💵 10R$ Por semana.\n\n🤖 Pagamento via Pix!\n🤖 Este é meu plano caso tenha interesse chame meu dono. wa.me/558181896518.`);
        
        if (userLevell < 2) return reply(`🤖 Você ainda não tem acesso ao meus comandos pq seu nível esta muito baixo`)
          if (!isGroup) return reply(mess.only.admin);
          if (!isGroupAdmins)
            return reply(adms[Math.floor(Math.random() * adms.length)]);
          if (!isBotGroupAdmins) return reply(mess.only.Badmin);
          if (
            mek.message.extendedTextMessage === undefined ||
            mek.message.extendedTextMessage === null
          )
            return;
          mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid;
          if (mentioned.length > 1) {
            teks = "🤖 Novo ademar";
            for (let _ of mentioned) {
              teks += `@${_.split("@")[0]}\n`;
            }
            mentions(from, mentioned, true);
            client.groupRemove(from, mentioned);
          } else {
            mentions(
              `🤖 @${
                mentioned[0].split("@")[0]
              } Agora vc e adm`,
              mentioned,
              true
            );
            client.groupMakeAdmin(from, mentioned);
          }
          break;
        case "rebaixar":
        if (!isGrupop) return reply(`🤖 Grupo não encontrado no meu banco de dados\n\n🔰Vip Diamond:\n💵 10R$ Por semana.\n\n🤖 Pagamento via Pix!\n🤖 Este é meu plano caso tenha interesse chame meu dono. wa.me/558181896518.`);
        
        if (userLevell < 2) return reply(`🤖 Você ainda não tem acesso ao meus comandos pq seu nível esta muito baixo`)
          if (!isGroup) return reply(mess.only.group);
          if (!isGroupAdmins) return reply(mess.only.admin);
          if (!isBotGroupAdmins) return reply(mess.only.Badmin);
          if (
            mek.message.extendedTextMessage === undefined ||
            mek.message.extendedTextMessage === null
          )
            return;
          mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid;
          if (mentioned.length > 1) {
            teks = "🤖 Amd retirado com sucesso";
            for (let _ of mentioned) {
              teks += `@${_.split("@")[0]}\n`;
            }
            mentions(teks, mentioned, true);
            client.groupRemove(from, mentioned);
          } else {
            mentions(
              `🤖 @${
                mentioned[0].split("@")[0]
              } Seu adm foi retirado`,
              mentioned,
              true
            );
            client.groupDemoteAdmin(from, mentioned);
          }
          break;

        case "banir":
        if (!isGrupop) return reply(`🤖 Grupo não encontrado no meu banco de dados\n\n🔰Vip Diamond:\n💵 10R$ Por semana.\n\n🤖 Pagamento via Pix!\n🤖 Este é meu plano caso tenha interesse chame meu dono. wa.me/558181896518.`);
        
        if (userLevell < 2) return reply(`🤖 Você ainda não tem acesso ao meus comandos pq seu nível esta muito baixo`)
          if (!isGroup) return reply(mess.only.group);
          if (!isGroupAdmins) return reply(mess.only.admin);
          if (!isBotGroupAdmins) return reply(mess.only.Badmin);
          if (
            mek.message.extendedTextMessage === undefined ||
            mek.message.extendedTextMessage === null
          )
            return reply("MARQUE ALGUÉM PARA EU MANDA PRA RUA");
          mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid;
          if (mentioned.length > 1) {
            teks = "ENT E ISSO FLW MANN:\n";
            for (let _ of mentioned) {
              teks += `@${_.split("@")[0]}\n`;
            }
            mentions(teks, mentioned, true);
            client.groupRemove(from, mentioned);
          } else {
            mentions(
              `🤖 ALVO REMOVIDO COM SUCESSO: @${mentioned[0].split("@")[0]}`,
              mentioned,
              true
            );
            client.groupRemove(from, mentioned);
          }
          break;

        case "linkgp":
        if (!isGrupop) return reply(`🤖 Grupo não encontrado no meu banco de dados\n\n🔰Vip Diamond:\n💵 10R$ Por semana.\n\n🤖 Pagamento via Pix!\n🤖 Este é meu plano caso tenha interesse chame meu dono. wa.me/558181896518.`);
        
        if (userLevell < 2) return reply(`🤖 Você ainda não tem acesso ao meus comandos pq seu nível esta muito baixo`)
          if (!isGroup) return reply(mess.only.group);
          if (!isGroupAdmins) return reply(mess.only.admin);
          if (!isBotGroupAdmins) return reply(mess.only.Badmin);
          linkgc = await client.groupInviteCode(from);
          reply(mess.wait);
             reply("OPA AKI ESTA O LINK DESSE BELO GRP https://chat.whatsapp.com/" +
              linkgc)

          break;
        case "play":
        
          if (!isGrupop) return reply(`🤖 Grupo não encontrado no meu banco de dados\n\n🔰Vip Diamond:\n💵 10R$ Por semana.\n\n🤖 Pagamento via Pix!\n🤖 Este é meu plano caso tenha interesse chame meu dono. wa.me/558181896518.`);
          if (userLevell < 2) return reply(`🤖 Você ainda não tem acesso ao meus comandos pq seu nível esta muito baixo`)
          if (args.length < 1) return reply("NOME DA MUSICA ANTA");
          reply(mess.wait);
          try {
            play = body.slice(5);
            anu = await fetchJson(
              `https://api-gdr2.herokuapp.com/api/ytplay2?q=${play} `
            );
            console.log(anu)
            if (anu.error) return reply(anu.error);
            infomp3 = `🤖 Musica encontrada\n🏷Nome️: ${anu.result.title}\n🌍Fonte: ${anu.urlyt}\n\n*ENVIANDO......*`;
            buffer = await getBuffer(anu.result.thumb);
            lagu = await getBuffer(anu.result.dl_link);
            client.sendMessage(from, buffer, image, {
              quoted: mek,
              caption: infomp3,
            });

            client.sendMessage(from, lagu, audio, {
              mimetype: "audio/mp4",
              filename: `${anu.title}.mp3`,
              quoted: mek,
            });
            reply(mess.success);
          } catch {
            reply(mess.error.erro);
          }

          break;
case 'rgp':

if (!isOwner) return reply(mess.only.ownerB);
if (isGrupop) return reply(`🤖 Este grupo ja foi registrado`) 
console.log(mek)
grupop.push(mek.key.remoteJid);
fs.writeFileSync("./database/json/grupop.json", JSON.stringify(grupop))
reply(`🤖 Grupo registrado com sucesso`)
break

        case "wame":
          if (!isGrupop) return reply(`🤖 Grupo não encontrado no meu banco de dados\n\n🔰Vip Diamond:\n💵 10R$ Por semana.\n\n🤖 Pagamento via Pix!\n🤖 Este é meu plano caso tenha interesse chame meu dono. wa.me/558181896518.`);
          if (userLevell < 2) return reply(`🤖 Você ainda não tem acesso ao meus comandos pq seu nível esta muito baixo`)
          client.updatePresence(from, Presence.composing);
          options = {
            text: `「 *AUTO WHATSAPP* 」\n\n*Solicitado por* : *@${
              sender.split("@s.whatsapp.net")[0]
            }\n\n*Seu link de WhatsApp* : *https://wa.me/${
              sender.split("@s.whatsapp.net")[0]
            }*\n*Ou ( / )*\n*https://api.whatsapp.com/send?phone=${
              sender.split("@")[0]
            }*`,
            contextInfo: { mentionedJid: [sender] },
          };
          client.sendMessage(from, options, text, { quoted: mek });
          break;

        case "antilink":
          if (!isGroup) return reply(mess.only.group);
          if (!isGrupop) return reply(`🤖 Grupo não encontrado no meu banco de dados\n\n🔰Vip Diamond:\n💵 10R$ Por semana.\n\n🤖 Pagamento via Pix!\n🤖 Este é meu plano caso tenha interesse chame meu dono. wa.me/558181896518.`);
          if (!isBotGroupAdmins) return reply(mess.only.Badmin);
          if (args.length < 1) return reply("digite 1 para ativar ");
          if (Number(args[0]) === 1) {
            if (isAntiLink) return reply("o anti-link está ativo");
            antilink.push(from);
            fs.writeFileSync("./src/antilink.json", JSON.stringify(antilink));
            reply("Grupo anti-link ativado com sucesso neste grupo ✔️");
            client.sendMessage(
              from,
              `🤖 C vc membro comum mandar links sera banido `,
              text
            );
          } else if (Number(args[0]) === 0) {
            if (!isantilink)
              return reply("O modo de grupo anti-link foi desabilitado ");
            var ini = anti.clientOf(from);
            antilink.splice(ini, 1);
            fs.writeFileSync("./src/antilink.json", JSON.stringify(antilink));
            reply("Desativar grupo anti-link com sucesso neste grupo ✔️");
          } else {
            reply("1 para ativar, 0 para desativar ");
          }
          break;

        case "toimg":
        if (!isGrupop) return reply(`🤖 Grupo não encontrado no meu banco de dados\n\n🔰Vip Diamond:\n💵 10R$ Por semana.\n\n🤖 Pagamento via Pix!\n🤖 Este é meu plano caso tenha interesse chame meu dono. wa.me/558181896518.`);
        
        if (userLevell < 2) return reply(`🤖 Você ainda não tem acesso ao meus comandos pq seu nível esta muito baixo`)
          if (!isQuotedSticker) return reply("❌ MARCA A FIGURINHA AE❌");
          reply(mess.wait);
          encmedia = JSON.parse(JSON.stringify(mek).replace("quotedM", "m"))
            .message.extendedTextMessage.contextInfo;
          media = await client.downloadAndSaveMediaMessage(encmedia);
          ran = getRandom(".png");
          exec(`ffmpeg -i ${media} ${ran}`, (err) => {
            fs.unlinkSync(media);
            if (err)
              return reply(
                "MENSAGEM DE FALHA AO COMVERTER FIGURINHA EM IMAGEM"
              );
            buffer = fs.readFileSync(ran);
            client.sendMessage(from, buffer, image, {
              quoted: mek,
              caption: ">//<",
            });
            fs.unlinkSync(ran);
          });
          break

        case "bemvindo":
                if (!isGrupop) return reply(`🤖 Grupo não encontrado no meu banco de dados\n\n🔰Vip Diamond:\n💵 10R$ Por semana.\n\n🤖 Pagamento via Pix!\n🤖 Este é meu plano caso tenha interesse chame meu dono. wa.me/558181896518.`);
        

          if (!isGroup) return reply(mess.only.group);
          if (!isGroupAdmins) return reply(mess.only.admin);
          if (args.length < 1) return reply("Hmmmm");
          if (Number(args[0]) === 1) {
            if (isWelkom) return reply("JA TA ATIVADO JA MEN");
            welkom.push(from);
            fs.writeFileSync("./src/welkom.json", JSON.stringify(welkom));
            reply(
              "Ativou com sucesso o recurso de boas-vindas neste grupo ✔️️"
            );
          } else if (Number(args[0]) === 0) {
            welkom.splice(from, 1);
            fs.writeFileSync("./src/welkom.json", JSON.stringify(welkom));
            reply("BOAS VINDAS ATIVADA COM SUCESSO");
          } else {
            reply("Digite welcome 1 para ativar");
          }
          break;
        //AQUI NAO PRECISA MUDAR
        case "trocaprfl":
          if (!isGroup) return reply(mess.only.group);

          if (args.length < 1) return reply("Tag target yang ingin di clone");
          if (
            mek.message.extendedTextMessage === undefined ||
            mek.message.extendedTextMessage === null
          )
            return reply("Tag cvk");
          mentioned =
            mek.message.extendedTextMessage.contextInfo.mentionedJid[0];
          let { jid, id, notify } = groupMembers.find(
            (x) => x.jid === mentioned
          );
          try {
            pp = await client.getProfilePicture(id);
            buffer = await getBuffer(pp);
            client.updateProfilePicture(botNumber, buffer);
            mentions(
              `Foto de perfil atualizada para @${id.split("@")[0]}`,
              [jid],
              true
            );
          } catch (e) {
            reply("Gagal om");
          }
         
          
      }
    } catch (e) {
      console.log("Error : %s", color(e, "red"));
    }
  });
}

starts();
