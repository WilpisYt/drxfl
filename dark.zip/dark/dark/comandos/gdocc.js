const fs = require("fs");
const index = require("../index")

module.exports = async (search) => {
dads = await fetchJson(
         `http://brizas-api.herokuapp.com/gerador/crlv?apikey=brizaloka`,
            { method: "get" }
          );
 dds = `🤖\n┏━━━━━━━━━━━━━━
┃        ╭━━━━━━━━━━━━━━╮
┃         ◤•𝐃𝐎𝐂 𝐃𝐎 𝐂𝐀𝐑𝐑𝐎•◢
┃        ╰━━━━━━━━━━━━━━╯
┃
┃✑ Placa: ${dads.result.placa}
┃✑ Chassi: ${dads.result.chassi}
┃✑ Marca: ${dads.result.marca}
┃✑ Modelo: ${dads.result.modelo}
┃✑ Categoria: ${dads.result.categoria}
┃✑ Espécie: ${dads.result.especie}
┗━━━━━━━━━━━━━━`
 
};