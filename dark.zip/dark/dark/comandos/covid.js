const fs = require("fs");
const index = require("../index")


module.exports = async (search) => {
dadus = await fetchJson(
         `http://brizas-api.herokuapp.com/covidcountry?apikey=brizaloka&country=Brazil`,
            { method: "get" }
          );
 dds = `🤖\nCasos〉${dadus.resultado.casos}`
 console.log(dadus)
 
};
