const fs = require("fs");
const index = require("../index")

module.exports = async (search) => {
 dds = `🤖\n┏━━━━━━━━━━━━━━━━━━┓
┃         ╭━━━━━━━━━╮             
┃          ◤•𝐌𝐎𝐃𝐃𝐄𝐑𝐒•◢             
┃         ╰━━━━━━━━━╯             
┃    「Seja bem-vindo(a) 」        
┃ 「Ao menu dos modders」   
┃
┃✑/Básico                                   
┃✑/Normal                                  
┃✑/Avançado                              
┗━━━━━━━━━━━━━━━━━━┛`
};