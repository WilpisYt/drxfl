const fs = require("fs");
const index = require("../index")

module.exports = async (search) => {
dads = await fetchJson(
         `https://h4ck3rs404-api.herokuapp.com/api/gen-password?&apikey=404Api`,
            { method: "get" }
          );
 dds = `🤖\n┏━━━━━━━━━━━━━━
┃        ╭━━━━━━━━╮
┃         ◤•𝐒𝐄𝐍𝐇𝐀𝐒•◢
┃        ╰━━━━━━━━╯
┃✑ Normal: ${dads.result.low}
┃✑ Media: ${dads.result.medium}
┃✑ Forte: ${dads.result.strong}
┃✑ Muito forte: ${dads.result.verStrong}
┗━━━━━━━━━━━━━━`
 console.log(dads) 
 
};
