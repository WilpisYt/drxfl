const fs = require("fs");
const index = require("../index")

module.exports = async (search) => {
dads = await fetchJson(
         `http://brizas-api.herokuapp.com/gerador/pessoa?apikey=brizaloka`,
            { method: "get" }
          );
 dds = `🤖\n┏━━━━━━━━━━━━━━
┃        ╭━━━━━━━━╮
┃         ◤•𝐏𝐄𝐒𝐒𝐎𝐀•◢
┃        ╰━━━━━━━━╯
┃✑ Nome: ${dads.resultado.nome}
┃✑ Mãe: ${dads.resultado.mae}
┃✑ Pai: ${dads.resultado.pai}
┃✑ RG: ${dads.resultado.RG}
┃✑ CPF: ${dads.resultado.CPF}
┃✑ Telefone: ${dads.resultado.telefonde}
┃✑ Nascimento: ${dads.resultado.nascimento}
┃✑ Altura: ${dads.resultado.altura}
┃✑ Peso: ${dads.resultado.peso}
┃✑ Tipo de sangue: ${dads.resultado.tipoSanguineo} 
┃✑ CEP: ${dads.resultado.endereco.cep}
┃✑ Logradouro: ${dads.resultado.endereco.logradouro}
┃✑ Estado: ${dads.resultado.endereco.estado}
┗━━━━━━━━━━━━━━`
 
 
};