const fs = require("fs");
const index = require("../index")

module.exports = async (search) => {
dads = await fetchJson(
         `http://brizas-api.herokuapp.com/gerador/cpf?apikey=brizaloka`,
            { method: "get" }
          );
 dds = `🤖\n┏━━━━━━━━━━━━━━
┃        ╭━━━━━━━━╮
┃           ◤•𝐂𝐏𝐅•◢
┃        ╰━━━━━━━━╯
┃
┃✑ CPF: ${dads.CPF}
┗━━━━━━━━━━━━━━`
 
};