const fs = require('fs');

exports.tterro = () => {
	return `Você deve digitar ${prefix}ppt pedra, ${prefix}ppt papel ou ${prefix}ppt tesoura`
}
