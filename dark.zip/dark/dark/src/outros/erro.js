module.exports = [
  `🤖 Opa deu erro! Press F`,
  `🤖 Desculpe deu um errin aki.`,
  `⁤🤖 Ixi deu erro kkkk`,
  `🤖 Foi mal n consegui dessa vez!`,
];
