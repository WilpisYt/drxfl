module.exports = [
  `🤖 Opa ta na mão`,
  `🤖 Olha ate que n demorou tanto assim ne? ta ai`,
  `⁤🤖 Encontrei man`,
  `🤖 Opa resultado encontrado`,
];
