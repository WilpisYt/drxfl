module.exports = [
  `🤖 Opa to processando aguarde...`,
  `🤖 Xa cmg..`,
  `⁤🤖 Calma la meu patrão ja mando`,
  `🤖 Opa queta o facho nem tudo e na hora que c quer ne?...`,
];
