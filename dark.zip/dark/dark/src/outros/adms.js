module.exports = [
  `🤖 Opa Parece que vc n é ADEMI!`,
  `🤖 ADEMAR é vc?? pera parece que não.`,
  `⁤🤖 Ue membro comum tentando usar comando de ademar?`,
  `🤖 Krai man tu n e ADM n para de encher u sacu`,
];
