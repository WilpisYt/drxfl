module.exports = [
  `🤖 Opa Pelo que meu engenheiro me disse este comando n funciona em pv!!`,
  `🤖 Erro!! Este comando so funciona em gp`,
  `⁤🤖 Ops! isto n e um grupo`,
];
