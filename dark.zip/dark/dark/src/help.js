const help = (prefix) => {
	return `   *COMANDOS ABAIXO* 
       
*COMANDOS EM ${prefix}ajuda* `
        


}

exports.help = help
