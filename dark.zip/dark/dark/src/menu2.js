const menu2 = (prefix) => {
	return ` *COMANDOS EM .ajuda
`
}

exports.menu2 = menu2
