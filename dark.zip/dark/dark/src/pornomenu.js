const pornomenu = (prefix) => {
	return ` *COMANDOS ABAIXO* 

__█████████  ● ᏴϴͲ●ᎷᎬΝႮ●         
__█▄█████▄█   *DONO* : *ADRX*
__█▼▼▼▼▼█   *SATUS*: ON
_██ᏴϴͲ Ꮩ1.0██▌ Wa.me/558197660171
__█▲▲▲▲▲█ 
__█████████ 
____██_____██

┣━━━━°❀ ❬ *TIPO DE PORNO* ❭ ❀°━━━━┓
┃    
╠➥${prefix}vdsiriricas "gostosa na siririca 🤤"
╠➥${prefix}vdporno
╠➥${prefix}porno "fotos"
╠═════════════════════════
`
}

exports.pornomenu = pornomenu
