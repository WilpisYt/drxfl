const menulite = (prefix) => { 
return `
Mano, Tu é gay?, o comando nem está no menu 🥴
`
} 

exports.menulite = menulite