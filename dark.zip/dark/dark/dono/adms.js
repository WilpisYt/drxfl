const adms = (prefix) => { 
	return `   
╔══ ◤ *MENU DOS ADEMI* ◢
║╔▸ 
║╠ ${prefix}ban (mencionar mensg pra rmv)
║╠ ${prefix}kick [@] (vai remover o cara)
║╠ ${prefix}grupo f/a
║╠ ${prefix}add [@] (para adicionar alguém)
║╠ ${prefix}linkgp
║╠ ${prefix}add [@] (para adicionar alguém)
║╠ ${prefix}promover [@] (promover a adm)
║╠ ${prefix}rebaixar [@] (rebaixar adm)
║╠ ${prefix}grupoinfo
║╠ ${prefix}hidetag (txt) (ele marca todos)
║╠ ${prefix}marcar (marca tds do gp)
║╠ ${prefix}marcar1 (marca tds do gp)
║╠ ${prefix}antidocumento 1 / 0  
║╠ ${prefix}anticontato 1 / 0  
║╠ ${prefix}antiloc 1 / 0  
║╠ ${prefix}leveling 1 / 0  
║╠ ${prefix}antilink 1 / 0
║╠ ${prefix}antifake 1 / 0
║╠ ${prefix}bemvindo 1 / 0
║╠ ${prefix}simih 1 / 0
║╚▸
╚════ ◤ *${NamaBot}* ◢
`
}
exports.adms = adms