const owner = (prefix, ownerNumber, NamaBot) => {
	return`

╔════ ◤ *INFORMAÇÕES OWNER/BOT*◢
║╔▸ 
║╠ *Nome* :「 ${NamaOwner} 」
║╠ *Proprietário*: ${ownerNumber} 
║╠ *Youtube* : 「 ${ytb} 」
║╠ *Instagram* : ${instagram} 
║╠ *Prefix* : ${prefix} 
║╚▸
╚════ ◤ *${NamaBot}* ◢
`
}

exports.owner = owner