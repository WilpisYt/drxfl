const dono = (prefix) => {

	return `
╔══ ◤ *𝐌𝐄𝐍𝐔 𝐃𝐄 𝐃𝐎𝐍𝐎* ◢
║╔▸ 
║╠ ${prefix}serpremium
║╠ ${prefix}delpremium @(marca)
║╠ ${prefix}addpremium @(marca)
║╠ ${prefix}addlevel @(marca) (quantidade)
║╠ ${prefix}clonar [@] (rouba foto de perfil)
║╠ ${prefix}setppbot (img, = foto do BT)
║╠ ${prefix}setnomebot (nome do bot q c qr)
║╠ ${prefix}limpar (limpa todos chats do bot)
║╠ ${prefix}block [@] (bloq de usar cmds) 
║╠ ${prefix}unblock [@] (desbloquear) 
║╠ ${prefix}setprefix # de ! Pra = #
║╠ ${prefix}bc [texto] (ele faz uma™ pra td)
║╠ ${prefix}reiniciar (reinicia o bot no tr) 
║╚▸
╚════ ◤ *${NamaBot}* ◢
`
}
exports.dono = dono


