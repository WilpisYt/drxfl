const menumusic = (prefix, time, uptime, groupName) => {
	return`
	╔════ ◤ 𝑴𝒆𝒏𝒖 𝒅𝒆 𝑴𝒖𝒔𝒊𝒄𝒂𝒔 ◢
║╔▸ 
║╠  ${prefix}eletronic
║╠  ${prefix}eletronic2
║╠  ${prefix}eletronic3
║╠  ${prefix}eletronic4
║╠  ${prefix}eletronic5
║╠  ${prefix}eletronic6
║╠  ${prefix}music
║╠  ${prefix}music1
║╠  ${prefix}music2
║╠  ${prefix}music3
║╠  ${prefix}music4
║╠  ${prefix}music5
║╠  ${prefix}music6
║╠  ${prefix}music7
║╠  ${prefix}music8
║╠  ${prefix}music9
║╠  ${prefix}dj
║╠  ${prefix}dj2
║╠  ${prefix}dj3
║╠  ${prefix}dj4
║╠  ${prefix}dj5
║╠  ${prefix}sad
║╠  ${prefix}sad2
║╠  ${prefix}sad3
║╠  ${prefix}sad4
║╠  ${prefix}among
║╠  ${prefix}plutao 
║╠  ${prefix}sowell
║╠  ${prefix}tenso
║╠  ${prefix}eletro
║╠  ${prefix}suave
║╚▸
╚════ ◤ *${NamaBot}* ◢`
}
	
exports.menumusic = menumusic	