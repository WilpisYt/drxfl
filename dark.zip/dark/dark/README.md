# MELIODAS BOT

Este bot de WhatsApp tem o objetivo de resolver adminitrar um grp e entretenimento
## 💻 Tecnologias Utilizadas

<div style="display: inline_block"><br>
    <img align="center" alt="NodeJS" height="40" width="50" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/nodejs/nodejs-original.svg">
    </div>

<br />

## 🤖 INSTALAÇÃO DO BOT
     cd ~
     git clone git@github.com:guiireal/meliodas-bot.git
     cd meliodas-bot
     npm install
     npm start

<br />

## ⚙ Funcionalidades

- ✅ Recepção
- ✅ Cadastro do usuário
    - ✅ Nome
    - ✅ Telefone
    - ✅ Foto
- ✅ Bloquear palavrão
- ✅ Advertência

<br />

## 📋 MENU

## 🤖 FIGURINHAS

    - ✅ /F
    - ✅ /Figu "converter gif em figurinha animada"
    - ✅ /Toimg "converter iigurinha em imagem"
    - ❎ Em breve...
    - ❎ Em breve...
    - ❎ Em breve...
    - ❎ Em breve...

## 🤖 MIDIA

    - ✅ Play "baixa música"
    - ✅ Baixarvideo "por enquanto so baixa video do yt"
    - ❎ Em breve...
    - ❎ Em breve...
    - ❎ Em breve...
    - ❎ Em breve...

## 🤖 GRUPOS

    - ✅ /Play
    - ✅ /Baixarvideo
    - ✅ /F
    - ✅ /figu
    - ✅ /toimg
    - ✅ /add "add uma pessoa no gp"
    - ✅ /ttxt "envia travas"
    - ✅ /destravar "envia destravas"
    - ✅ /bemvindo[0-1] "ativa boas vindas"
    - ✅ /antlink[0-1] "ativa o modo de anti links"
    - ✅ /banir "remove a pessoa do go"
    - ✅ /promover "dar adm para alguém"
    - ✅ /rebaixar "tirar adm de alguém"
    - ✅ /txtf "cria figurinhas de texto"
    - ✅ /wame "pega link do teu número"
    - ✅ /grupoinfo "manda o nome e desc do gp"
    - ✅ /fechargp "fecha o gp"
    - ✅ /abrirgp "abre o gp" 
    - ✅ /linkgp "pega link do gp"
    - ✅ /wait "busca animes apenas com a foto"
    - ✅ /adrx "use para c registra" 
    - ✅ /grave[0-1] "dois niveis de grave"
            
## 🤖 COMANDOS DE ADM

    - ✅ /add
    - ✅ /promover 
    - ✅ /ttxt
    - ✅ /rebaixar
    - ✅ /antilink
    - ✅ /fechargp
    - ✅ /abrirgp
    - ✅ /linkgp
    - ✅ /banir

<br />

## 👨‍💻 Criador

- [Adryan](https://github.com/adrxA)

<br />
